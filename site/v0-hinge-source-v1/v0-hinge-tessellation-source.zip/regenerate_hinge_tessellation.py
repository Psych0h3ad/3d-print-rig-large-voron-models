# SPDX-License-Identifier: GPL-3.0-only
"""Regenerate the two V0 display tessellations from pinned public mesh source.

The editable recipe contains source-derived evaluated sample coordinates and
the authored tessellation patch. This reproduces the display asset, not a CAD
kernel evaluation, complete native trimming, mating or physical-fit proof.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,math,struct,sys,tempfile

def require(value,message):
    if not value:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def checked_relative(root,name):
    p=Path(name)
    require(not p.is_absolute()and'..'not in p.parts and'\\'not in name,'Unsafe source-relative path')
    return root/p
def read_accessor(fp,g,binary_start,ordinal):
    a=g['accessors'][ordinal];v=g['bufferViews'][a['bufferView']]
    require('sparse'not in a and not a.get('normalized',False)and v.get('buffer',0)==0,'Unexpected source accessor')
    fmt,width={5126:('f',4),5125:('I',4),5123:('H',2)}[a['componentType']];components={'VEC3':3,'SCALAR':1}[a['type']]
    count=a['count'];stride=v.get('byteStride',width*components);off=a.get('byteOffset',0)
    require(count>0 and stride>=width*components and off+(count-1)*stride+width*components<=v['byteLength'],'Source accessor exceeds view')
    fp.seek(binary_start+v.get('byteOffset',0)+off);raw=fp.read((count-1)*stride+width*components)
    require(len(raw)==(count-1)*stride+width*components,'Truncated source accessor')
    packed=b''.join(raw[i*stride:i*stride+width*components]for i in range(count))
    values=[struct.unpack_from('<'+fmt*components,packed,i*width*components)for i in range(count)]
    require(all(math.isfinite(float(x))for row in values for x in row),'Nonfinite source geometry')
    return packed,values

def generate(recipe_file,model_file,output):
    require(sys.flags.optimize==0,'Run with explicit nonoptimized source guards')
    recipe_file=Path(recipe_file);model_file=Path(model_file);output=Path(output)
    require(not output.exists(),'Use a new output directory')
    recipe_bytes=recipe_file.read_bytes();recipe=json.loads(recipe_bytes)
    require(recipe['schema']=='v0-source-hinge-editable-tessellation-v1','Unknown source recipe')
    metadata_file=checked_relative(recipe_file.parent,recipe['metadata']['path']);metadata_bytes=metadata_file.read_bytes()
    require(sha(metadata_bytes)==recipe['metadata']['sha256'],'Source metadata changed')
    metadata=json.loads(metadata_bytes);require(len(recipe['parts'])==len(metadata['parts'])==2,'Exactly two source parts required')
    with model_file.open('rb')as probe:packed_magic=probe.read(2)
    if packed_magic==b'\x1f\x8b':
        require(model_file.stat().st_size==recipe['source_model']['stored_bytes'],'Stored source model size changed')
        with model_file.open('rb')as source_fp:stored_hash=hashlib.file_digest(source_fp,'sha256').hexdigest()
        require(stored_hash==recipe['source_model']['stored_sha256'],'Stored source model bytes changed')
    reader=gzip.open(model_file,'rb')if packed_magic==b'\x1f\x8b'else model_file.open('rb')
    tree=dict(asset=dict(version='2.0',generator='3d-print-rig source-supported hinge geometry representation'),scene=0,scenes=[dict(nodes=[])],nodes=[],meshes=[],buffers=[dict(byteLength=0)],bufferViews=[],accessors=[]);blocks=[];offset=0
    with reader,tempfile.TemporaryFile()as fp:
        digest=hashlib.sha256();size=0
        while True:
            block=reader.read(1024*1024)
            if not block:break
            size+=len(block);require(size<=recipe['source_model']['decoded_bytes'],'Source model exceeds exact size');digest.update(block);fp.write(block)
        require(size==recipe['source_model']['decoded_bytes']and digest.hexdigest()==recipe['source_model']['decoded_sha256'],'Original source model changed')
        fp.seek(0);magic,version,total=struct.unpack('<4sII',fp.read(12));n,kind=struct.unpack('<I4s',fp.read(8));g=json.loads(fp.read(n));bn,bkind=struct.unpack('<I4s',fp.read(8));start=fp.tell()
        require((magic,version,kind,bkind)==(b'glTF',2,b'JSON',b'BIN\0')and total==size and start+bn==size,'Unexpected original GLB layout')
        for part,expected in zip(recipe['parts'],metadata['parts']):
            require(part['replacement_key']==expected['key'],'Source replacement order changed')
            node=g['nodes'][part['source_node']];mesh=g['meshes'][node['mesh']];require(len(mesh['primitives'])==1,'Unexpected original primitive count');primitive=mesh['primitives'][0]
            require(set(primitive['attributes'])=={'POSITION'},'Original NORMAL/attribute presence changed')
            original_position,original_points=read_accessor(fp,g,start,primitive['attributes']['POSITION']);original_index,original_indices=read_accessor(fp,g,start,primitive['indices'])
            require(sha(original_position)==part['original_position_sha256']and sha(original_index)==part['original_index_sha256'],'Exact original source buffers changed')
            require(len(original_points)==part['original_vertices']and len(original_indices)==part['original_triangles']*3,'Original source geometry counts changed')
            native=part['evaluated_source_samples_mm'];require(len(native)==86 and all(len(p)==3 and all(math.isfinite(x)for x in p)for p in native),'Complete finite source sample coordinates required')
            core=b''.join(struct.pack('<fff',p[0]*.001,p[2]*.001,p[1]*-.001)for p in native);position=original_position+core
            old=[list(v[0]for v in original_indices[i:i+3])for i in range(0,len(original_indices),3)];removed=part['replaced_original_triangle_ordinals'];require(len(set(removed))==len(removed)and all(isinstance(i,int)and 0<=i<len(old)for i in removed),'Invalid original patch ownership')
            removed_set=set(removed);indices=[t for i,t in enumerate(old)if i not in removed_set]+part['tessellation_patch_indices'];vertices=len(position)//12
            require(vertices==expected['vertices']and len(indices)==expected['triangles'],'Regenerated source tessellation count differs')
            require(all(len(t)==3 and len(set(t))==3 and all(isinstance(i,int)and 0<=i<vertices for i in t)for t in indices),'Invalid source triangle index')
            index=b''.join(struct.pack('<III',*t)for t in indices)
            require(sha(position)==expected['POSITION_sha256']and sha(index)==expected['index_sha256'],'Regenerated source geometry differs from reviewed buffers')
            points=list(struct.iter_unpack('<fff',position));bounds=part['position_accessor_bounds'];require(all(min(p[a]for p in points)==bounds['min'][a]and max(p[a]for p in points)==bounds['max'][a]for a in range(3)),'Source accessor bounds differ')
            attributes=[]
            for raw,target,component,typ,count in [(position,34962,5126,'VEC3',vertices),(index,34963,5125,'SCALAR',len(indices)*3)]:
                view=len(tree['bufferViews']);tree['bufferViews'].append(dict(buffer=0,byteOffset=offset,byteLength=len(raw),target=target));access=dict(bufferView=view,componentType=component,count=count,type=typ)
                if typ=='VEC3':access.update(min=bounds['min'],max=bounds['max'])
                attributes.append(len(tree['accessors']));tree['accessors'].append(access);blocks.append(raw);offset+=len(raw)
            key=expected['key'];tree['scenes'][0]['nodes'].append(len(tree['nodes']));tree['nodes'].append(dict(name=key,mesh=len(tree['meshes']),extras=dict(hinge_source_role=expected['role'],replacement_key=key)));tree['meshes'].append(dict(name=key,primitives=[dict(attributes=dict(POSITION=attributes[0]),indices=attributes[1],mode=4)]))
    binary=b''.join(blocks);tree['buffers'][0]['byteLength']=len(binary);encoded=json.dumps(tree,separators=(',',':')).encode();encoded+=b' '*(-len(encoded)%4)
    raw=struct.pack('<4sII',b'glTF',2,28+len(encoded)+len(binary))+struct.pack('<I4s',len(encoded),b'JSON')+encoded+struct.pack('<I4s',len(binary),b'BIN\0')+binary
    require(len(raw)==metadata['model']['decoded_bytes']and sha(raw)==metadata['model']['decoded_sha256'],'Regenerated GLB bytes differ')
    compressed=bytearray(gzip.compress(raw,compresslevel=9,mtime=0));compressed[9]=recipe['gzip_os_byte'];compressed=bytes(compressed)
    require(len(compressed)==metadata['model']['bytes']and sha(compressed)==metadata['model']['sha256'],'Compressor differs from exact stored bytes; do not substitute a new pin')
    output.mkdir(parents=True);(output/'v0_hinge_source_tessellation.glb.gz').write_bytes(compressed);(output/'v0_hinge_source_tessellation.json').write_bytes(metadata_bytes)
    return dict(passed=True,source_recipe_sha256=sha(recipe_bytes),model_bytes=len(compressed),model_sha256=sha(compressed),decoded_sha256=sha(raw),metadata_sha256=sha(metadata_bytes),native_kernel_evaluation_replayed=False,native_fit_verified=False)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--recipe',type=Path,required=True);p.add_argument('--source-model',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    print(json.dumps(generate(a.recipe,a.source_model,a.output)))
if __name__=='__main__':main()
