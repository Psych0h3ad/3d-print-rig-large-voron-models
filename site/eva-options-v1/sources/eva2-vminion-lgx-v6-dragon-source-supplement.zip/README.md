# EVA 2 / V-Minion LGX Lite: V6 and Dragon derivation sources

This source-only supplement covers exactly `eva2_vminion_lgx_v6_129` and
`eva2_vminion_lgx_dragon_129`. It contains retained preprocessing and composition
source, exact leaf-selection recipes, native datum measurements, operation
receipts, public input references and license evidence. It contains no CAD or
mesh binaries. No independent reconstruction or new native audit was performed
when packaging this supplement. It does not certify full physical fit.

## Inputs and versions

`PUBLIC_INPUTS.json` records original downloaded bytes, SHA-256, public URLs,
exact native revision and export flags. Place these separately acquired inputs
at the listed paths relative to `work/`. Run retained scripts from `work/`.
The public V-Minion assembly is v1.0 v7; original 90-leaf head model and metadata
are separately hash-pinned public inputs. V6 and Dragon assemblies use exact
Onshape microversions, not an inferred EVA patch version. A fresh STEP export
can have different serialization; these historical native input hashes must
not silently be replaced with a current author workspace export.

## Retained derivation sequence

1. `native_module_preparer.py` contains the original public STEP inspection and
   selected-leaf export algorithms. `native-reference/NATIVE_REFERENCE.json`
   and `native-{v6,dragon}/INVENTORY.json` contain exact source occurrences,
   analytic features, BRep hashes and native bounds. Source BReps referenced
   in receipts must be extracted from the pinned native input before running
   native preprocessing; they are deliberately not bundled.
2. `fit_native_module.py` derives the module frame from two exact authored
   screw axes and trimmed mating endpoints. `*-frame-selection.json` and
   `*_NATIVE_FRAME.json` retain selected datums and the measured transform.
   Source origin is [70, 0, 0] mm; viewer mapping is (x-70, z, -y)*0.001.
3. `prepare_composition_base.py` preserves the original public base geometry
   and material buffers while adding explicit provenance.
   `annotate_base_printed.py` preserves the original twelve individual printed
   occurrences. `purchased-materials.json` is the exact source-bound hardware
   material table used by the base preparation.
4. `prepare_native_bridges_and_tubes_r4.py` removes three authored 0.25 mm
   hole-covering support membranes from the Universal face, and trims the
   original PTFE radial geometry between the authored hotend seat and LGX
   socket endpoint. `export_prepared_native_modules_r4.py` retains the module
   export step. The precise operations and resulting BRep pins are in the
   accompanying receipts and export recipes.
5. For Dragon, `check_dragon_source_membranes.py` and
   `prepare_dragon_counterbore_closures_r5.py` preserve the original four
   additional 0.25 mm counterbore-closure preparations. The accepted operation
   is `native_counterbore_closure`, using the native head-pocket radius. Thus
   V6 has three removed built-in support membranes and Dragon seven total.
6. `export_authored_face_fasteners_r4.py` selects unchanged author V6 DIN M3x25
   occurrences 10 and 20. `check_authored_dragon_screws.py` preserves the native
   axis/bores/nut proof for replacing Dragon occurrences 14 and 33 with this
   exact pair. The final Dragon composition recipe already selects that pair;
   no generic bolt, scaling or arbitrary translation is introduced.
7. `lgx-v6-composition-recipe-r4.json` and
   `lgx-dragon-composition-recipe-r6.json` preserve final exact part selections,
   source identities and companion memberships. `compose_eva_options.py` is
   the retained source-pinned compositor. Its CLI is
   `python compose_eva_options.py RECIPE OUTPUT_DIRECTORY` after preparing and
   checking all described inputs. It copies selected geometry buffers and
   native placement matrices rather than inventing a new assembled frame.

## Recipe and evidence scope

The paths in packaged recipes use a clean relative reproduction layout.
`RETAINED_GENERATOR_PROVENANCE.json` records original and packaged hashes and
specific source adaptations. Included JSON proof descriptors have been rebound
where needed to the packaged JSON bytes. Prepared mesh/BRep hashes and
`evidence/` receipts remain historical recorded outputs; they are not a claim
that these intermediate files are included or were regenerated here. Rebuilding
can change serialized JSON, gzip and recipe hashes; each new output requires
its own checks and receipt. Do not treat a changed recipe hash as the original
released hash. `RELEASED_ASSET_PINS.json` records the accepted payload bytes.

Final composition recipes retain the printed `endstop_mount` carrier and the
purchased `endstop` switch as distinct categories, and the retained carriage
occurrence BRep proof. The metadata/GLB extras of any regenerated output must
preserve those fields and exact native source identities. This package supplies
retained derivation sources and evidence, not an independently tested one-command
rebuild or a new release/clearance audit. Existing front-surface proofs remain
separate source-bound inputs; no front geometry was changed by packaging.

## Source notices

EVA2 official STEP documentation links the live author CAD under its GPLv3
notice. The pinned tagged EVA2 repository LICENSE separately declares
CC-BY-NC-SA-4.0. Both acquired notices and hashes are retained in `licenses/`.
Retained Rat Rig V-Minion source is separately attributed as CC-BY-NC-SA-4.0.
This supplement assigns no unified license to mixed-source CAD and infers no
additional purchased-component rights or dual-license grant from download
access. See `LICENSE_NOTICES.md` and the evidence for exact scopes.
