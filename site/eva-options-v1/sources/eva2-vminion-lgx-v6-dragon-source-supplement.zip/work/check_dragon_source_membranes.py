"""Bounded source bore closure review; preserve both untouched native witnesses."""
import hashlib,json,math
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from native_geometry_helpers import bounds,write
Q=Path(__file__).resolve().parent
inv=json.loads((Q/'native-dragon/INVENTORY.json').read_text(encoding='utf8'))
row=inv['leaves'][6];native=cq.Shape.importBrep(str(Q/'native-dragon/6.brep'))
def volume_common(a,b):
    op=BRepAlgoAPI_Common(a.wrapped,b.wrapped);op.Build();assert op.IsDone()
    return sum(s.Volume() for s in cq.Shape.cast(op.Shape()).Solids())
rows=[]
for radius_scope in ['through_bore','native_counterbore_closure']:
    after=native;caps=[]
    for index in [14,15,16,17]:
        bore=next(f for f in row['native_features'] if f['face']==index)
        end=np.asarray(bore['axis_origin_mm'])+np.asarray(bore['axis_direction'])*bore['uv_bounds'][3]
        pocket=min([f for f in row['native_features'] if f['type']=='cylinder' and abs(f['radius_mm']-2.4)<1e-9],
                   key=lambda f:np.linalg.norm(np.cross(np.asarray(f['axis_origin_mm'])-end,np.asarray(bore['axis_direction']))))
        floor=np.asarray(pocket['axis_origin_mm'])+np.asarray(pocket['axis_direction'])*pocket['uv_bounds'][2]
        assert np.linalg.norm(np.cross(floor-end,np.asarray(bore['axis_direction'])))<1e-9
        thickness=float(np.dot(floor-end,np.asarray(bore['axis_direction'])))
        assert abs(thickness-.25)<1e-9
        radius=bore['radius_mm'] if radius_scope=='through_bore' else pocket['radius_mm']
        cutter=cq.Solid.makeCylinder(radius,thickness+2e-7,cq.Vector(*(end-np.asarray(bore['axis_direction'])*1e-7)),cq.Vector(*bore['axis_direction']))
        removed=volume_common(after,cutter)
        assert abs(removed-math.pi*radius**2*.25)<1e-4
        after=after.cut(cutter).clean();assert after.isValid()
        caps.append({'through_bore':bore,'native_head_pocket':pocket,'closure_trim_mm':[end.tolist(),floor.tolist()],
                     'closure_thickness_mm':thickness,'radius_mm':radius,'removed_volume_mm3':removed})
    solids=[]
    for index in [21,25,27,31]:
        bolt=cq.Shape.importBrep(str(Q/f'native-dragon/{index}.brep'))
        solids.append({'source_screw_index':index,'remaining_common_mm3':volume_common(after,bolt)})
    out=Q/f'dragon-{radius_scope}-prepared-test.brep';after.exportBrep(str(out))
    rows.append({'scope':radius_scope,'caps':caps,'source_volume_mm3':native.Volume(),'prepared_volume_mm3':after.Volume(),
      'original_native_bounds_mm':bounds(native).tolist(),'prepared_native_bounds_mm':bounds(after).tolist(),
      'source_face_key':'eva2_author_dragon_006','source_brep_sha256':row['brep_sha256'],
      'prepared_brep':{'file':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},
      'current_authored_fastener_common':solids,'all_thread_flanks_verified':False})
    print(json.dumps({'scope':radius_scope,'remaining':solids}),flush=True)
write(Q/'DRAGON_SOURCE_MEMBRANE_REVIEW.json',{'rows':rows,
  'author_post_print_instruction':'https://2.eva-3d.page/printing/#pokey-pokey-hole-technique',
  'scope':'Two explicit source hole-closure preparations measured against exact author screws; no arbitrary face cut and no physical-fit certification.'})
