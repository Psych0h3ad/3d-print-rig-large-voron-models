"""Use unchanged same-author DIN hardware with exact native mating axes."""
import json,gzip,hashlib,subprocess,sys
from pathlib import Path
import numpy as np
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from native_geometry_helpers import transformed,write,sha
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def desc(p,gz=False):
    b=p.read_bytes();d={'file':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    if gz:
        raw=gzip.decompress(b);d.update(encoding='gzip',decoded_bytes=len(raw),decoded_sha256=hashlib.sha256(raw).hexdigest())
    return d
native=read(Q/'native-reference/NATIVE_REFERENCE.json')['parts']
v6=read(Q/'native-v6/INVENTORY.json')['leaves'];dragon=read(Q/'native-dragon/INVENTORY.json')['leaves']
vm=np.asarray(read(Q/'V6_NATIVE_FRAME.json')['source_to_vminion_native_mm'])
dm=np.asarray(read(Q/'DRAGON_NATIVE_FRAME.json')['source_to_vminion_native_mm'])
face=transformed(cq.Shape.importBrep(str(Q/'native-dragon/6.brep')),dm)
rows=[]
for oldindex,newindex,nutkey,holeface in [(14,10,348,27),(33,20,349,28)]:
    old=next(f for f in dragon[oldindex]['native_features'] if f['type']=='cylinder' and abs(f['radius_mm']-1.5)<1e-9)
    fresh=next(f for f in v6[newindex]['native_features'] if f['type']=='cylinder' and abs(f['radius_mm']-1.5)<1e-9)
    hole=next(f for f in dragon[6]['native_features'] if f['face']==holeface)
    nut=native[nutkey-315]['cylinders'][0]
    fp=vm[:3,:3]@np.asarray(fresh['axis_origin_mm'])+vm[:3,3]
    fd=vm[:3,:3]@np.asarray(fresh['axis_direction'])
    op=dm[:3,:3]@np.asarray(old['axis_origin_mm'])+dm[:3,3]
    od=dm[:3,:3]@np.asarray(old['axis_direction'])
    hp=dm[:3,:3]@np.asarray(hole['axis_origin_mm'])+dm[:3,3]
    hole_error=float(np.linalg.norm(np.cross(hp-fp,fd)))
    nut_error=float(np.linalg.norm(np.cross(np.asarray(nut['axis_origin_mm'])-fp,fd)))
    old_error=float(np.linalg.norm(np.cross(np.asarray(nut['axis_origin_mm'])-op,od)))
    assert hole_error<1e-6 and nut_error<1e-6 and old_error>.14
    bolt=transformed(cq.Shape.importBrep(str(Q/f'native-v6/{newindex}.brep')),vm)
    common=BRepAlgoAPI_Common(face.wrapped,bolt.wrapped);common.Build();assert common.IsDone()
    volume=sum(s.Volume() for s in cq.Shape.cast(common.Shape()).Solids());assert volume<1e-8
    rows.append({'original_dragon_screw_index':oldindex,'replacement_v6_screw_index':newindex,
      'original_dragon_screw_occurrence':{k:dragon[oldindex][k] for k in ['source_path','source_label_path','definition_label','brep_sha256']},
      'replacement_v6_screw_occurrence':{k:v6[newindex][k] for k in ['source_path','source_label_path','definition_label','brep_sha256']},
      'original_source_nut_axis_error_mm':old_error,'replacement_source_nut_axis_error_mm':nut_error,
      'replacement_dragon_clearance_hole_axis_error_mm':hole_error,'dragon_hole_feature':hole,'retained_nut_feature':nut,
      'replacement_source_nominal_shaft':fresh,'unchanged_v6_module_to_host_native_mm':vm.tolist(),
      'replacement_vs_untouched_dragon_face_common_mm3':volume})
write(Q/'DRAGON_FACE_SCREW_SOURCE_RESOLUTION_R6.json',{'rows':rows,
 'scope':'Current Dragon assembly places its two nominal M3 face screws approximately 0.147 mm off the retained nut axes. Replacements are exact unchanged DIN M3x25 occurrences from the same EVA author V6 assembly, using its independently measured original native module frame. Both source Dragon clearance bores and original source nuts are coaxial with these replacements. No arbitrary translation, resized hardware or generic approximation.',
 'full_thread_fit_certified':False})
