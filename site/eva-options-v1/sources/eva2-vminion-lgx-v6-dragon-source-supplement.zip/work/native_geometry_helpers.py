"""Retained exact native geometry helper functions."""
import hashlib,json
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.gp import gp_Trsf
Q=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p,v):
    assert p.resolve().is_relative_to(Q.resolve())
    p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf8')

def transformed(shape,matrix):
    tr=gp_Trsf(); tr.SetValues(*np.asarray(matrix)[:3].reshape(-1).tolist())
    return cq.Shape.cast(shape.wrapped.Moved(cq.Location(tr).wrapped))

def bounds(shape):
    b=shape.BoundingBox(); return np.asarray([[b.xmin,b.ymin,b.zmin],[b.xmax,b.ymax,b.zmax]])
