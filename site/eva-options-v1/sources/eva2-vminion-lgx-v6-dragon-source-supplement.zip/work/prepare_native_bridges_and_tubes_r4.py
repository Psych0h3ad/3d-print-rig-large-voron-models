"""Exact source bore bridge and consumable-tube preparations, not arbitrary fit repair."""
import hashlib,json
from pathlib import Path
import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from native_module_preparer import bounds,json_write,read_native,sha
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return {'file':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
ref=read(Q/'native-reference/NATIVE_REFERENCE.json')['parts']
source=read(Q/'prepared-base/PREPARATION_RECEIPT.json')['input']
native={**source['native_source'],'source_revision':source['source_revision'],
 'public_url':'https://a360.co/3rPymJS','license':'CC-BY-NC-SA-4.0'}
doc,reader,leaves=read_native(native,{tuple(ref[i]['source_path']) for i in [11,5]})
selected=[]
for nativeindex,operation in [(11,'source_bore_bridge_removal'),(5,'source_hotend_seat_tube_trim')]:
    target=ref[nativeindex]
    row,shape=next((r,s) for r,s in leaves if r['source_path']==target['source_path'])
    original=Q/'native-reference'/f'{nativeindex}.brep'
    assert sha(original.read_bytes())==target['brep_sha256']
    if nativeindex==11:
        # Existing r1.65 clearance bore terminates Y29.75; native adjacent
        # pocket floor is Y30. The author's Pokey Pokey method expressly says
        # to pierce these 0.2-0.3mm hole-covering bridge layers after printing.
        axis=next(c for c in target['cylinders'] if c['face']==2)
        x,z=axis['axis_origin_mm'][0],axis['axis_origin_mm'][2]
        cutter=cq.Solid.makeCylinder(axis['radius_mm'],.2500002,cq.Vector(x,29.74999820888049-.0000001,z),cq.Vector(0,1,0))
        after=shape.cut(cutter).clean();assert after.isValid()
        bore_bridges=[]
        for face_index in [0,1]:
            f=next(c for c in target['cylinders'] if c['face']==face_index)
            import numpy as np
            endpoint=np.asarray(f['axis_origin_mm'])+np.asarray(f['axis_direction'])*f['uv_bounds'][2]
            additional=cq.Solid.makeCylinder(f['radius_mm'],.2500002,cq.Vector(*(endpoint-np.asarray(f['axis_direction'])*.2500001)),cq.Vector(*f['axis_direction']))
            before_volume=after.Volume();after=after.cut(additional).clean();assert after.isValid()
            removed_volume=before_volume-after.Volume()
            assert abs(removed_volume-3.141592653589793*f['radius_mm']**2*.25)<1e-4
            bore_bridges.append({'source_bore_feature':f,'native_bore_trim_endpoint_mm':endpoint.tolist(),'thickness_mm':.25,'removed_volume_mm3':removed_volume})
        common=BRepAlgoAPI_Common(shape.wrapped,cutter.wrapped);common.Build();assert common.IsDone()
        removed=cq.Shape.cast(common.Shape())
        assert abs(removed.Volume()-3.141592653589793*axis['radius_mm']**2*.25)<1e-4
        output=Q/'native-prepared-r4'/'universal-face-installed.brep';output.parent.mkdir(exist_ok=True);after.exportBrep(str(output))
        receipt={'operation':operation,'source_sha256':native['sha256'],
          'source_identity':[row['source_path'],row['source_label_path'],row['definition_label']],
          'source_brep':pin(original),'prepared_brep':pin(output),'source_bore_feature':axis,
          'source_membrane_native_Y_mm':[29.74999820888049,29.99999820888049],'additional_bridge_caps':bore_bridges,
          'removed_volume_mm3':removed.Volume(),'removed_bounds_mm':bounds(removed),
          'author_instruction_url':'https://2.eva-3d.page/printing/#pokey-pokey-hole-technique',
          'author_instruction_scope':'Native hole-covering bridge layer removed as required after printing; outer model and source mating geometry retained.',
          'notice':'The original universal face hole-covering built-in support has been removed for assembled viewing. This is a prepared model, not the untouched printable source.'}
        receiptfile=Q/'native-prepared-r4'/'universal-face-installed-receipt.json';json_write(receiptfile,receipt)
        selection={k:row[k] for k in ['source_path','source_label_path','definition_label']}
        selection.update(key='eva2_vminion_lgx_bmo_326',appearance_role='accent',eva_companions=['core'],
          native_preparation={'receipt':pin(receiptfile),'source_brep':pin(original),'prepared_brep':pin(output)})
        selected.append(selection)
    else:
        for kind,lo in [('v6',145.6),('dragon',160.6)]:
            # Lower end follows the authored hotend PTFE seat; upper end follows
            # the retained LGX body's native socket trim endpoint. The original
            # overlong source tube must not extend into its filament channel.
            socket=next(c for c in ref[23]['cylinders'] if c['face']==3)
            import numpy as np
            endpoint=np.asarray(socket['axis_origin_mm'])+np.asarray(socket['axis_direction'])*socket['uv_bounds'][3]
            upper=float(endpoint[2])
            keep=cq.Solid.makeBox(20,20,upper-lo,cq.Vector(-27.5,3.5,lo))
            after=shape.intersect(keep).clean();assert after.isValid()
            assert abs(after.Volume()-3.141592653589793*3*(upper-lo))<1e-6
            output=Q/'native-prepared-r4'/f'lgx-{kind}-tube.brep';after.exportBrep(str(output))
            receipt={'operation':operation,'source_sha256':native['sha256'],
              'source_identity':[row['source_path'],row['source_label_path'],row['definition_label']],
              'source_brep':pin(original),'prepared_brep':pin(output),
              'source_cylinder_features':target['cylinders'],
              'original_incorrect_tube_upper_end_mm':target['bounds_mm'][1][2],'native_extruder_socket_feature':socket,'native_extruder_socket_end_mm':endpoint.tolist(),'prepared_native_upper_end_mm':upper,'hotend_authored_ptfe_lower_end_mm':lo,
              'prepared_length_mm':upper-lo,'hotend_native_frame_sha256':sha((Q/f'{kind.upper()}_NATIVE_FRAME.json').read_bytes()),
              'scope':'Original public V-Minion consumable PTFE trimmed between the authored hotend seat and retained LGX body socket endpoint; original radial geometry and filament axis retained.'}
            receiptfile=Q/'native-prepared-r4'/f'lgx-{kind}-tube-receipt.json';json_write(receiptfile,receipt)
            selection={k:row[k] for k in ['source_path','source_label_path','definition_label']}
            selection.update(key=f'eva2_lgx_{kind}_prepared_ptfe',appearance_role='hardware',eva_companions=['filament_guide'],
              native_preparation={'receipt':pin(receiptfile),'source_brep':pin(original),'prepared_brep':pin(output)})
            selected.append(selection)
proof={'schema':'eva2-native-module-core-datum-proof-v1','source':native,'source_origin_mm':[70,0,0],
 'source_to_vminion_native_mm':[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],'mount_axis_error_mm':0,
 'scope':'Native original whole-host occurrences; no translation or assembly relocation. Only authored bridge removal and consumable PTFE cut are explicit operations.'}
proof_file=Q/'native-prepared-r4'/'SOURCE_FRAME.json';json_write(proof_file,proof)
recipe={'id':'eva2_stock_native_prepared_modules','native_source':native,'source_origin_mm':[70,0,0],
 'source_to_vminion_native_mm':proof['source_to_vminion_native_mm'],'transform_proof':pin(proof_file),'leaves':selected}
for name,index in [('stock-prepared',0),('lgx-v6-tube',1),('lgx-dragon-tube',2)]:
    single={**recipe,'id':'eva2_'+name+'_module','leaves':[selected[index]]}
    json_write(Q/f'{name}-export-recipe-r4.json',single)
print(json.dumps({'prepared_parts':len(selected),'recipes':['stock-prepared','lgx-v6-tube','lgx-dragon-tube']}))
