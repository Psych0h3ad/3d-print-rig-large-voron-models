"""One bounded parse of the pinned public baseline, three prepared occurrences."""
import json
from pathlib import Path
import native_module_preparer as n
Q=Path(__file__).resolve().parent
names=['stock-prepared','lgx-v6-tube','lgx-dragon-tube']
recipes=[json.loads((Q/f'{name}-export-recipe-r4.json').read_text(encoding='utf8')) for name in names]
desc=recipes[0]['native_source']
paths={tuple(r['source_path']) for recipe in recipes for r in recipe['leaves']}
doc,reader,rows=n.read_native(desc,paths)
def checked_cache(source,selected_paths=None):
    assert source==desc
    n.checked(source)
    return doc,reader,[(r,s) for r,s in rows if selected_paths is None or tuple(r['source_path']) in selected_paths]
n.read_native=checked_cache
for name,recipe in zip(names,recipes):
    result=n.export(recipe,Q/f'module-{name}-r4')
    print(json.dumps({'module':name,'parts':result['parts'],'model':result['model']}),flush=True)
