"""Exact current author face screws in their already-proved native module frame."""
import copy,json
from pathlib import Path
import native_module_preparer as n
Q=Path(__file__).resolve().parent
for kind,indices in [('v6',[10,20])]:
    recipe=json.loads((Q/f'{kind}-export-recipe.json').read_text(encoding='utf8'))
    inv=json.loads((Q/f'native-{kind}/INVENTORY.json').read_text(encoding='utf8'))
    source=copy.deepcopy(recipe['native_source'])
    recipe=copy.deepcopy(recipe)
    recipe['id']=f'eva2_author_{kind}_face_fasteners'
    recipe['native_source']=source
    recipe['native_source']['license']='GPL-3.0 STEP-page notice / CC-BY-NC-SA-4.0 tagged LICENSE; exact live CAD applicability unresolved'
    recipe['leaves']=[]
    for index in indices:
        row=next(r for r in inv['leaves'] if r['ordinal']==index)
        selection={k:row[k] for k in ['source_path','source_label_path','definition_label']}
        selection.update(key=f'eva2_author_{kind}_facebolt_{index:03d}',appearance_role='hardware',
                         eva_companions=['fasteners'],metallic=0,roughness=.45)
        recipe['leaves'].append(selection)
    n.json_write(Q/f'{kind}-face-fasteners-export-recipe-r4.json',recipe)
    receipt=n.export(recipe,Q/f'module-{kind}-face-fasteners-r4')
    print(json.dumps({'module':kind+'-face-fasteners','parts':receipt['parts'],'model':receipt['model']}),flush=True)
