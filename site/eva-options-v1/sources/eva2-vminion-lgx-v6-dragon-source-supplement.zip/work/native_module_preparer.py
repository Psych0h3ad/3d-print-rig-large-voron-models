"""Inspect/export explicitly pinned public native modules; writes only EVA2 output.

Inspection never selects guessed hardware. Export requires an explicit leaf map,
an independently measured rigid transform and source provenance. Missing faces,
invalid solids, collapsed Float32 triangles and incomplete classifications fail.
"""
import argparse
import gzip
import hashlib
import json
import math
import struct
from collections import defaultdict
from pathlib import Path

import cadquery as cq
import numpy as np
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.Bnd import Bnd_Box
from OCP.GeomAbs import GeomAbs_Cylinder, GeomAbs_Plane
from OCP.IFSelect import IFSelect_RetDone
from OCP.Quantity import Quantity_ColorRGBA
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TCollection import TCollection_AsciiString, TCollection_ExtendedString
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label, TDF_LabelSequence, TDF_Tool
from OCP.TDocStd import TDocStd_Document
from OCP.TopLoc import TopLoc_Location
from OCP.XCAFDoc import XCAFDoc_ColorGen, XCAFDoc_ColorSurf, XCAFDoc_DocumentTool

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_write(path, data):
    within(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=True)+'\n', encoding='utf8')


def within(path):
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('Output must stay beside the reproduction scripts')


def checked(desc):
    data = Path(desc['file']).read_bytes()
    if len(data) != desc['bytes'] or sha(data) != desc['sha256']:
        raise ValueError('Public native source differs from explicit pin')
    return data


def entry(label):
    value = TCollection_AsciiString()
    TDF_Tool.Entry_s(label, value)
    return value.ToCString()


def name(label):
    value = TDataStd_Name()
    return value.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(), value) else entry(label)


def xyz(point):
    return [point.X(), point.Y(), point.Z()]


def bounds(shape):
    box = Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped, box, False, False)
    v = box.Get()
    return [list(v[:3]), list(v[3:])]


def source_identity(row):
    return (tuple(row['source_path']), tuple(row['source_label_path']), row['definition_label'])


def read_native(desc, selected_paths=None):
    checked(desc)
    doc = TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader = STEPCAFControl_Reader()
    reader.SetColorMode(True)
    reader.SetNameMode(True)
    assert reader.ReadFile(str(Path(desc['file']))) == IFSelect_RetDone
    assert reader.Transfer(doc)
    shape_tool = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    color_tool = XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    roots = TDF_LabelSequence()
    shape_tool.GetFreeShapes(roots)
    leaves = []

    def color(label=None, shape=None):
        for kind in (XCAFDoc_ColorSurf, XCAFDoc_ColorGen):
            c = Quantity_ColorRGBA()
            ok = color_tool.GetColor_s(label, kind, c) if label is not None else color_tool.GetColor(shape, kind, c)
            if ok:
                rgb = c.GetRGB()
                return [rgb.Red(), rgb.Green(), rgb.Blue(), c.Alpha()]
        return None

    def walk(label, parent=TopLoc_Location(), path=(), ids=(), inherited=None):
        path = path+(name(label),)
        ids = ids+(entry(label),)
        own_color = color(label=label) or inherited
        if shape_tool.IsReference_s(label):
            referred = TDF_Label()
            assert shape_tool.GetReferredShape_s(label, referred)
            location = parent.Multiplied(shape_tool.GetLocation_s(label))
            return definition(referred, location, path, ids, own_color)
        return definition(label, parent, path, ids, own_color)

    def definition(label, location, path, ids, inherited):
        own_color = color(label=label) or inherited
        if shape_tool.IsAssembly_s(label):
            children = TDF_LabelSequence()
            shape_tool.GetComponents_s(label, children, False)
            for i in range(1, children.Length()+1):
                walk(children.Value(i), location, path, ids, own_color)
        else:
            if selected_paths is not None and path not in selected_paths:
                return
            source = shape_tool.GetShape_s(label)
            if source.IsNull():
                raise ValueError('Empty native source occurrence')
            world = cq.Shape.cast(source.Moved(location))
            local = cq.Shape.cast(source)
            own_color = color(shape=source) or own_color
            solid_colors = [(s, color(shape=s.wrapped)) for s in local.Solids()]
            face_colors = []
            for face in local.Faces():
                rgba = color(shape=face.wrapped)
                origin = 'native_face'
                if rgba is None:
                    for solid, solid_color in solid_colors:
                        if solid_color is not None and any(face.wrapped.IsSame(f.wrapped) for f in solid.Faces()):
                            rgba = solid_color
                            origin = 'native_solid'
                            break
                if rgba is None:
                    rgba = own_color
                    origin = 'native_occurrence'
                face_colors.append({'rgba_linear': rgba, 'origin': origin if rgba is not None else 'unassigned'})
            row = {'ordinal': len(leaves), 'name': path[-1], 'source_definition': name(label),
                'source_path': list(path), 'source_label_path': list(ids), 'definition_label': entry(label),
                'source_revision': desc['source_revision'], 'source_sha256': desc['sha256'],
                'native_transform': [[location.Transformation().Value(r,c) for c in range(1,5)] for r in range(1,4)],
                'bounds_mm': bounds(world), 'valid': world.isValid(), 'solids': len(world.Solids()),
                'faces': len(world.Faces()), 'volume_mm3': world.Volume(), 'face_colors': face_colors}
            assert len(face_colors) == len(world.Faces())
            leaves.append((row, world))

    for i in range(1, roots.Length()+1):
        walk(roots.Value(i))
    return doc, reader, leaves


def inspect(desc, output):
    within(output)
    output.mkdir(parents=True, exist_ok=True)
    doc, reader, leaves = read_native(desc)
    rows = []
    for row, shape in leaves:
        features = []
        for index, face in enumerate(shape.Faces()):
            a = BRepAdaptor_Surface(face.wrapped, True)
            common = {'face': index, 'area_mm2': face.Area(), 'bounds_mm': bounds(face)}
            if a.GetType() == GeomAbs_Cylinder:
                c = a.Cylinder()
                features.append({**common, 'type': 'cylinder', 'radius_mm': c.Radius(),
                    'axis_origin_mm': xyz(c.Location()), 'axis_direction': xyz(c.Axis().Direction()),
                    'uv_bounds': [a.FirstUParameter(), a.LastUParameter(), a.FirstVParameter(), a.LastVParameter()]})
            elif a.GetType() == GeomAbs_Plane and face.Area() > 20:
                p = a.Plane()
                features.append({**common, 'type': 'plane', 'origin_mm': xyz(p.Location()),
                    'normal': xyz(p.Axis().Direction())})
        target = output/f"{row['ordinal']}.brep"
        shape.exportBrep(str(target))
        rows.append({**row, 'brep_sha256': sha(target.read_bytes()), 'native_features': features})
    result = {'schema': 'eva2-public-module-native-inventory-v1', 'source': desc,
        'leaves': rows, 'scope': 'Exact author STEP occurrences, placements, colors and analytic surfaces; no fit certificate.'}
    json_write(output/'INVENTORY.json', result)
    return {'leaves': len(rows), 'invalid': [r['ordinal'] for r in rows if not r['valid']]}


def export(recipe, output):
    within(output)
    if output.exists():
        raise ValueError('Candidate output already exists; preserve receipts')
    desc = recipe['native_source']
    checked(desc)
    if not desc.get('public_url') or not desc.get('license'):
        raise ValueError('Explicit public source/license required')
    origin = np.asarray(recipe['source_origin_mm'], dtype=float)
    transform = np.asarray(recipe['source_to_vminion_native_mm'], dtype=float)
    if (origin.shape != (3,) or transform.shape != (4,4) or not np.isfinite(transform).all()
            or not np.allclose(transform[3], [0,0,0,1], atol=1e-12)):
        raise ValueError('Invalid native source frame')
    rot = transform[:3,:3]
    if not np.allclose(rot.T@rot, np.eye(3), atol=1e-9) or abs(np.linalg.det(rot)-1)>1e-9:
        raise ValueError('Native module transform must be a proper rigid transform')
    proof_raw = Path(recipe['transform_proof']['file']).read_bytes()
    if sha(proof_raw) != recipe['transform_proof']['sha256']:
        raise ValueError('Native mating-feature proof differs from explicit pin')
    proof=json.loads(proof_raw)
    if (proof.get('schema')!='eva2-native-module-core-datum-proof-v1'
            or proof['source']['sha256']!=desc['sha256']
            or proof['source']['source_revision']!=desc['source_revision']
            or proof['source_origin_mm']!=origin.tolist()
            or not np.allclose(proof['source_to_vminion_native_mm'],transform,rtol=0,atol=1e-10)
            or not math.isfinite(proof['mount_axis_error_mm']) or proof['mount_axis_error_mm']>.05):
        raise ValueError('Export native frame is not bound to its measured source mating proof')
    selected_paths={tuple(r['source_path']) for r in recipe['leaves']}
    doc, reader, leaves = read_native(desc, selected_paths)
    by_identity={source_identity(r):(r,s) for r,s in leaves}
    if len(by_identity)!=len(leaves):
        raise ValueError('Ambiguous native source occurrence identities')
    model = {'asset': {'version': '2.0'}, 'scene': 0, 'scenes': [{'nodes': []}],
        'nodes': [], 'meshes': [], 'materials': [], 'accessors': [], 'bufferViews': []}
    binary = bytearray()
    parts, materials, used = [], {}, set()

    def attribute(a, component, kind, target, with_bounds=False):
        binary.extend(b'\0'*(-len(binary)%4))
        view = len(model['bufferViews'])
        model['bufferViews'].append({'buffer': 0, 'byteOffset': len(binary), 'byteLength': a.nbytes, 'target': target})
        binary.extend(a.tobytes())
        accessor = {'bufferView': view, 'componentType': component, 'count': len(a), 'type': kind}
        if with_bounds:
            accessor.update(min=a.min(axis=0).tolist(), max=a.max(axis=0).tolist())
        model['accessors'].append(accessor)
        return len(model['accessors'])-1

    for selected in recipe['leaves']:
        identity=source_identity(selected)
        if identity in used or identity not in by_identity:
            raise ValueError('Missing/repeated explicit native source occurrence')
        used.add(identity)
        row, shape = by_identity[identity]
        if not row['valid'] or not row['solids']:
            raise ValueError('Native solid needs bounded review before export')
        role = selected['appearance_role']
        if role not in ['base','accent','hardware'] or not selected['eva_companions']:
            raise ValueError('Missing explicit palette/companion classification')
        derivation=None
        if selected.get('native_preparation'):
            preparation=selected['native_preparation']
            receipt_raw=Path(preparation['receipt']['file']).read_bytes()
            assert sha(receipt_raw)==preparation['receipt']['sha256']
            receipt=json.loads(receipt_raw)
            assert receipt['source_sha256']==desc['sha256'] and receipt['source_identity']==[row['source_path'],row['source_label_path'],row['definition_label']]
            before_file=Path(preparation['source_brep']['file'])
            assert sha(before_file.read_bytes())==preparation['source_brep']['sha256']
            original=cq.Shape.importBrep(str(before_file))
            # These shapes come from the same exact source occurrence; the
            # operation itself is pinned and checked by the native reviewer.
            assert abs(original.Volume()-shape.Volume())<1e-7
            after_file=Path(preparation['prepared_brep']['file'])
            assert sha(after_file.read_bytes())==preparation['prepared_brep']['sha256']
            shape=cq.Shape.importBrep(str(after_file));assert shape.isValid()
            derivation=receipt
            source_colors=[c['rgba_linear'] for c in row['face_colors'] if c['rgba_linear'] is not None]
            assert source_colors and all(c==source_colors[0] for c in source_colors)
            row['face_colors']=[{'rgba_linear':source_colors[0],'origin':'unchanged_uniform_native_material'} for face in shape.Faces()]
        key = selected['key']
        groups = defaultdict(list)
        face_evidence = []
        mesher = BRepMesh_IncrementalMesh(shape.wrapped, .025, False, .16, False)
        assert mesher.IsDone()
        for fi, face in enumerate(shape.Faces()):
            verts, tris = face.tessellate(.025, .16)
            if not tris:
                raise ValueError(f'Native face not meshed: {key}/{fi}; no face may be omitted')
            xyz_mm = np.asarray([v.toTuple() for v in verts], dtype=float)
            indices = np.asarray(tris, dtype=int)
            native = xyz_mm[indices]
            cross = np.cross(native[:,1]-native[:,0], native[:,2]-native[:,0])
            lengths = np.linalg.norm(cross, axis=1)
            if not np.isfinite(native).all() or not np.isfinite(lengths).all():
                raise ValueError(f'Native nonfinite triangles: {key}/{fi}')
            # OpenCascade emits mathematically empty facets at singular native
            # surface poles. Only exactly zero-area facets may be removed; the
            # authored face must still be fully represented by valid facets.
            source_zero_facets=int(np.sum(lengths==0))
            positive=lengths>0
            native,cross,lengths=native[positive],cross[positive],lengths[positive]
            if not len(native):
                raise ValueError(f'Native face has no positive-area facets: {key}/{fi}')
            world = native@rot.T+transform[:3,3]
            rendered = ((world-origin)[:,:,[0,2,1]]*[.001,.001,-.001]).astype('<f4')
            area = np.linalg.norm(np.cross(rendered[:,1].astype(float)-rendered[:,0],
                rendered[:,2].astype(float)-rendered[:,0]),axis=1)
            if np.any(area<=0):
                raise ValueError(f'Float32-collapsed authored geometry: {key}/{fi}; retain original solid for repair')
            normal = ((cross/lengths[:,None])@rot.T)[:,[0,2,1]]*[1,1,-1]
            normal = np.repeat(normal[:,None,:],3,axis=1).astype('<f4')
            rgba = row['face_colors'][fi]['rgba_linear']
            if rgba is None:
                rgba = selected.get('unassigned_source_color_linear')
                if rgba is None:
                    raise ValueError(f'Unassigned source material: {key}/{fi}; require explicit reviewed fallback')
            groups[tuple(rgba)].append(np.c_[rendered.reshape(-1,3),normal.reshape(-1,3)])
            face_evidence.append({'face':fi, 'triangles':len(native), 'native_area_mm2':face.Area(),
                'original_tessellator_empty_facets':source_zero_facets,'native_face_omitted':False,
                'source_color_origin':row['face_colors'][fi]['origin']})
        primitives, all_vertices = [], []
        for rgba, values in groups.items():
            values = np.concatenate(values).astype('<f4')
            assert np.isfinite(values).all()
            assert np.max(abs(np.linalg.norm(values[:,3:].astype(float),axis=1)-1))<2e-7
            if rgba not in materials:
                materials[rgba] = len(model['materials'])
                model['materials'].append({'pbrMetallicRoughness': {'baseColorFactor':list(rgba),
                    'metallicFactor':selected.get('metallic',0), 'roughnessFactor':selected.get('roughness',.45)}})
            primitives.append({'attributes': {
                'POSITION':attribute(values[:,:3].copy(),5126,'VEC3',34962,True),
                'NORMAL':attribute(values[:,3:].copy(),5126,'VEC3',34962)},
                'indices':attribute(np.arange(len(values),dtype='<u4'),5125,'SCALAR',34963),
                'material':materials[rgba], 'mode':4})
            all_vertices.append(values[:,:3])
        positions=np.concatenate(all_vertices)
        # Metadata uses viewer-relative native XYZ millimetres. GLB geometry
        # independently uses metres in the (x,z,-y) viewer basis.
        restored=np.column_stack([positions[:,0],-positions[:,2],positions[:,1]]).astype(float)*1000
        target_bounds=[(restored.min(axis=0)+origin).tolist(),(restored.max(axis=0)+origin).tolist()]
        identity={k:row[k] for k in ['source_path','source_label_path','definition_label','source_revision','source_sha256','source_definition']}
        metadata={**identity, 'key':key, 'name':row['name'], 'group':'head', 'printed':role!='hardware',
            'appearance_role':None if role=='hardware' else role, 'eva_companions':selected['eva_companions'],
            'source_native_bounds_mm':row['bounds_mm'], 'native_bounds_mm':target_bounds,
            'bounds_mm':[restored.min(axis=0).tolist(),restored.max(axis=0).tolist()],
            'native_author_occurrence_transform':row['native_transform'],
            'module_to_host_native_mm':transform.tolist(), 'faces_exported':face_evidence}
        if derivation:
            metadata['native_preparation']=derivation
            metadata['supports_removed']=derivation.get('operation')=='source_bore_bridge_removal'
        node={'name':row['name'], 'mesh':len(model['meshes']),
            'extras':{**metadata,'part_key':key}}
        model['meshes'].append({'name':row['name'], 'primitives':primitives})
        model['scenes'][0]['nodes'].append(len(model['nodes']))
        model['nodes'].append(node)
        parts.append(metadata)
    if not parts or len({p['key'] for p in parts})!=len(parts):
        raise ValueError('Empty/repeated candidate output')
    binary.extend(b'\0'*(-len(binary)%4))
    model['buffers']=[{'byteLength':len(binary)}]
    body=json.dumps(model,separators=(',',':'),ensure_ascii=True).encode()
    body+=b' '*(-len(body)%4)
    data=struct.pack('<IIIII',0x46546C67,2,28+len(body)+len(binary),len(body),0x4E4F534A)+body+struct.pack('<II',len(binary),0x004E4942)+binary
    packed=gzip.compress(data,mtime=0)
    output.mkdir(parents=True)
    (output/'model.glb.gz').write_bytes(packed)
    json_write(output/'parts.json', {'id':recipe['id'], 'source_origin_mm':origin.tolist(),
        'source_revision':desc['source_revision'], 'eva_generation':2, 'eva_version':None,
        'eva_version_scope':'source_assembly', 'native_source':desc, 'parts':parts})
    receipt={'schema':'eva2-public-native-module-export-v1', 'id':recipe['id'],
        'native_source':desc, 'transform_proof_sha256':sha(proof_raw), 'source_to_vminion_native_mm':transform.tolist(),
        'source_origin_mm':origin.tolist(), 'mapping':'(native_x-70,native_z,-native_y)*.001',
        'parts':len(parts), 'faces':sum(len(p['faces_exported']) for p in parts),
        'model':{'bytes':len(packed),'sha256':sha(packed),'decoded_bytes':len(data),'decoded_sha256':sha(data)},
        'scope':'Exact selected source native solid tessellation, rigid datum transform, unit normals and source materials. No full-printer clearance certification.'}
    json_write(output/'EXPORT_RECEIPT.json',receipt)
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['inspect','export'])
    parser.add_argument('recipe',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    recipe=json.loads(args.recipe.read_text(encoding='utf8'))
    result=inspect(recipe,args.output) if args.operation=='inspect' else export(recipe,args.output)
    print(json.dumps(result,ensure_ascii=True))
