"""Add explicit original native provenance without changing retained geometry."""
import gzip
import hashlib
import json
import struct
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'inputs/baseline'
SOURCE=ROOT/'inputs/official-1.step'
REV='6811558082d6a1797dac160ca027692cd7904a4b'
STEP_SHA='46650c0be0527b0f799a6ebd5cde210254caafdc4c436f558857fa30c17e9b94'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def write_json(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf8')

def main():
    source=SOURCE.read_bytes()
    assert sha(source)==STEP_SHA
    packed=(BASE/'model.glb.gz').read_bytes()
    assert sha(packed)=='6bc9646adc104c066d7a568d3a6d21dd0392b29392eaae920b1240bf955d43fb'
    data=gzip.decompress(packed)
    assert sha(data)=='21b8cf9694d86062e6b124051c1b60b963d66328a0df7a1b45ba2baaabd46b3b'
    meta_raw=(BASE/'parts.json').read_bytes()
    assert sha(meta_raw)=='9831dc9193fab6d3c98e4b3e9b2d8348f8c2345b1137de13e7730a7869adae92'
    meta=json.loads(meta_raw)
    size=struct.unpack_from('<I',data,12)[0]
    doc=json.loads(data[20:20+size])
    binary=data[28+size:]
    assert struct.unpack_from('<I',data,24+size)[0]==0x004E4942
    native=json.loads((ROOT/'native-reference/NATIVE_REFERENCE.json').read_text(encoding='utf8'))
    assert native['original_STEP_sha256']==STEP_SHA
    identities={tuple(r['source_path']):r for r in native['parts']}
    assert len(identities)==len(meta['parts'])==90
    parts={p['key']:p for p in meta['parts']}
    anonymous_receipts=[]
    for part in parts.values():
        path=tuple(part['source_path'])
        if path in identities:
            row=identities[path]
            assert part['name'].rstrip(':1')==row['definition'].rstrip(':1')
        else:
            # The exact source-preserving subset has two importer-generated
            # anonymous labels with renumbered XCAF label IDs. Preserve the
            # original full-source identities from the pinned base metadata;
            # do not substitute the subset's labels or invent a new CAD name.
            expected={'eva2_vminion_lgx_bmo_319':('118',4),
                      'eva2_vminion_lgx_bmo_345':('143',30)}
            assert part['key'] in expected
            original_label,subset_index=expected[part['key']]
            assert part['source_path'][-1]==f'=>[0:1:1:{original_label}]'
            row=native['parts'][subset_index]
            assert part['source_path'][:-1]==row['source_path'][:-1]
            anonymous_receipts.append({'key':part['key'],'original_source_path_retained':part['source_path'],
                'subset_source_path_not_substituted':row['source_path'],
                'identity_evidence':'Original hash-pinned base metadata; source-preserving native subset retains original geometry/entities.'})
        part['source_revision']=REV
        part['source_sha256']=STEP_SHA
    owners={}
    for node in doc['nodes']:
        key=node.get('extras',{}).get('part_key')
        if key not in parts:continue
        assert key not in owners
        owners[key]=node
        node['extras'].update({field:parts[key][field] for field in ['source_path','source_revision','source_sha256']})
    assert set(owners)==set(parts)
    purchased=json.loads((ROOT/'purchased-materials.json').read_text(encoding='utf8'))
    for number, expected in purchased.items():
        key='eva2_vminion_lgx_bmo_'+number
        node=owners[key]
        assert parts[key]['appearance_role'] not in ['base','accent']
        for primitive in doc['meshes'][node['mesh']]['primitives']:
            pbr=doc['materials'][primitive['material']]['pbrMetallicRoughness']
            assert pbr['baseColorFactor'][:3]==expected['color_linear']
            assert pbr['metallicFactor']==expected['metalness']
            assert pbr['roughnessFactor']==expected['roughness']
    body=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode()
    body+=b' '*(-len(body)%4)
    result=struct.pack('<IIIII',0x46546C67,2,28+len(body)+len(binary),len(body),0x4E4F534A)+body+struct.pack('<II',len(binary),0x004E4942)+binary
    target=ROOT/'prepared-base'
    target.mkdir(exist_ok=False)
    outpacked=gzip.compress(result,mtime=0)
    (target/'model.glb.gz').write_bytes(outpacked)
    write_json(target/'parts.json',meta)
    metadata=(target/'parts.json').read_bytes()
    receipt={'schema':'eva2-explicit-native-base-preparation-v1', 'original_decoded_model_sha256':sha(data),
        'original_metadata_sha256':sha(meta_raw), 'geometry_buffers_sha256':sha(binary),
        'unchanged_geometry_buffers':True,'unchanged_meshes_materials_matrices':True,
        'annotated_native_source_parts':90,'purchased_materials_preserved':list(purchased),
        'anonymous_original_identity_receipts':anonymous_receipts,
        'front_geometry':'Original source BRep/occurrence remains unchanged; The unchanged source front must use its separately pinned front-surface proof.',
        'input':{'model':{'file':str(target/'model.glb.gz'),'bytes':len(outpacked),'sha256':sha(outpacked),
                'encoding':'gzip','decoded_bytes':len(result),'decoded_sha256':sha(result)},
            'metadata':{'file':str(target/'parts.json'),'bytes':len(metadata),'sha256':sha(metadata)},
            'native_source':{'file':str(SOURCE),'bytes':len(source),'sha256':sha(source)},
            'source_revision':REV,'keys':list(parts)},
        'scope':'Composition preparation, original geometry/material preservation and explicit public native provenance only; not an additional configuration or fit certificate.'}
    write_json(target/'PREPARATION_RECEIPT.json',receipt)
    print(json.dumps({'parts':90,'geometry_buffers_unchanged':True,'input':receipt['input']}))

if __name__=='__main__':main()
