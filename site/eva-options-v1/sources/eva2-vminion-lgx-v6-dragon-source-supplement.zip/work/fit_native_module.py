"""Solve native EVA2 author assembly frame from exact core mating features.

The source core occurrence and its two interface face ordinals must be selected
from the saved native inventory. This does not infer a physical fit from boxes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()

def normalized(value):
    value=np.asarray(value,dtype=float)
    assert value.shape==(3,) and np.isfinite(value).all()
    assert np.linalg.norm(value)>0
    return value/np.linalg.norm(value)

def feature_frame(anchors):
    # Cylinder axis origins alone can lie anywhere along the infinite axes.
    # Use the trimmed source mating-end plane explicitly declared in selection.
    points=np.asarray([a['mating_center_mm'] for a in anchors],dtype=float)
    ex=normalized(points[1]-points[0])
    ey=normalized(anchors[0]['into_core_direction'])
    assert abs(np.dot(ex,ey))<1e-8
    ez=normalized(np.cross(ex,ey))
    assert np.dot(ey,normalized(anchors[1]['into_core_direction']))>1-1e-8
    return points,np.column_stack([ex,ey,ez])

def main(selection,out):
    if not out.resolve().is_relative_to(ROOT.resolve()):raise ValueError('Output outside reproduction directory')
    raw=Path(selection['inventory']['file']).read_bytes()
    assert sha(raw)==selection['inventory']['sha256']
    inventory=json.loads(raw)
    source=inventory['source']
    source_raw=Path(source['file']).read_bytes()
    assert len(source_raw)==source['bytes'] and sha(source_raw)==source['sha256']
    row=next(r for r in inventory['leaves'] if r['source_path']==selection['core_source_path'])
    native_raw=(ROOT/'native-reference/NATIVE_REFERENCE.json').read_bytes()
    native=json.loads(native_raw)
    target_core=native['parts'][11]
    target_features=[next(c for c in target_core['cylinders'] if c['face']==f) for f in [119,118]]
    target=[{'mating_center_mm':r['axis_origin_mm'],'into_core_direction':r['axis_direction']} for r in target_features]
    anchors=[]
    for supplied in selection['interface_anchors']:
        face=next(f for f in row['native_features'] if f['face']==supplied['face'])
        assert face['type']=='cylinder' and abs(face['radius_mm']-1.65)<1e-6
        center=np.asarray(supplied['mating_center_mm'],dtype=float)
        axis_origin=np.asarray(face['axis_origin_mm'])
        axis=normalized(face['axis_direction'])
        axis_error=np.linalg.norm(np.cross(center-axis_origin,axis))
        assert axis_error<1e-6
        # Supplied mating center must be an authored trim endpoint on this exact
        # cylinder, not an arbitrary point chosen on its infinite extension.
        _,_,vmin,vmax=face['uv_bounds']
        endpoints=[axis_origin+axis*v for v in [vmin,vmax]]
        trim_error=min(np.linalg.norm(center-point) for point in endpoints)
        assert trim_error<.00001
        assert abs(np.dot(axis,normalized(supplied['into_core_direction'])))>1-1e-8
        anchors.append({**supplied,'native_face':face,'trim_endpoint_error_mm':float(trim_error),
            'axis_point_error_mm':float(axis_error)})
    assert len(anchors)==2
    s,source_frame=feature_frame(anchors)
    t,target_frame=feature_frame(target)
    rotation=target_frame@source_frame.T
    translation=t.mean(axis=0)-rotation@s.mean(axis=0)
    source_spacing=np.linalg.norm(s[1]-s[0]);target_spacing=np.linalg.norm(t[1]-t[0])
    assert abs(source_spacing-target_spacing)<.00001
    errors=np.linalg.norm(s@rotation.T+translation-t,axis=1)
    assert max(errors)<.00001
    matrix=np.eye(4);matrix[:3,:3]=rotation;matrix[:3,3]=translation
    result={'schema':'eva2-native-module-core-datum-proof-v1', 'source':source,
        'source_inventory_sha256':sha(raw),'source_core_path':row['source_path'],
        'source_core_brep_sha256':row['brep_sha256'],'source_interface_anchors':anchors,
        'target_core_source_sha256':native['original_STEP_sha256'],
        'target_core_path':target_core['source_path'],'target_core_brep_sha256':target_core['brep_sha256'],
        'target_native_cylinders':target_features,'source_origin_mm':[70,0,0],
        'source_to_vminion_native_mm':matrix.tolist(),'mount_axis_error_mm':float(max(errors)),
        'source_mount_spacing_mm':float(source_spacing),'target_mount_spacing_mm':float(target_spacing),
        'scaled':False,'mirror_transform':False,
        'scope':'Exact two authored screw axes, trim endpoints and source core mating-plane orientation. Separate new module/body/fastener/probe/nozzle checks still required; no universal fit certification.'}
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2,ensure_ascii=True)+'\n',encoding='utf8')
    print(json.dumps({'mount_axis_error_mm':result['mount_axis_error_mm'],'source_to_vminion_native_mm':matrix.tolist()}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('selection',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    main(json.loads(args.selection.read_text(encoding='utf8')),args.output)
