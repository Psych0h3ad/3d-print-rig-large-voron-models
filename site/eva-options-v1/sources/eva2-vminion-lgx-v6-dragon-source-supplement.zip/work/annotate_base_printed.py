"""Annotate the exact twelve source printed occurrences, preserving geometry."""
import copy,gzip,hashlib,json,struct,subprocess,sys
from pathlib import Path
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf8')
def desc(p,gz=False):
    b=p.read_bytes();d={'file':str(p),'bytes':len(b),'sha256':sha(b)}
    if gz:
        raw=gzip.decompress(b);d.update(encoding='gzip',decoded_bytes=len(raw),decoded_sha256=sha(raw))
    return d
def module(folder,keys=None):
    meta=read(folder/'parts.json')
    return {'model':desc(folder/'model.glb.gz',True),'metadata':desc(folder/'parts.json'),
      'native_source':{k:meta['native_source'][k] for k in ['file','bytes','sha256']},
      'source_revision':meta['source_revision'],'keys':keys or [p['key'] for p in meta['parts']]}

# Source-proven twelve individual printed occurrences, not all descendants of
# their assembly parent. Purchased fans, extruder shells and motors stay false.
original=Q/'prepared-base';prepared=Q/'prepared-base-r4';prepared.mkdir(exist_ok=False)
meta=read(original/'parts.json');raw=gzip.decompress((original/'model.glb.gz').read_bytes())
jsonlength=struct.unpack_from('<I',raw,12)[0]
doc=json.loads(raw[20:20+jsonlength]);binarychunk=raw[20+jsonlength:]
printed_indices=set(range(324,336))
actual={int(p['key'].rsplit('_',1)[1]) for p in meta['parts'] if p.get('appearance_role') in ['base','accent']}
assert actual==printed_indices
records={p['key']:p for p in meta['parts']}
for key,p in records.items():
    assert p['source_path'] and p['source_revision'] and len(p['source_sha256'])==64
    p['printed']=int(key.rsplit('_',1)[1]) in printed_indices
    p['printed_classification_scope']='Individual original native occurrence, resolved from source identity and retained source appearance role.'
for node in doc['nodes']:
    key=node.get('extras',{}).get('part_key')
    if key in records:
        node['extras']['printed']=records[key]['printed']
        node['extras']['printed_classification_scope']=records[key]['printed_classification_scope']
body=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode();body+=b' '*(-len(body)%4)
decoded=struct.pack('<III',0x46546c67,2,20+len(body)+len(binarychunk))+struct.pack('<II',len(body),0x4e4f534a)+body+binarychunk
assert decoded[20+len(body):]==binarychunk
assert json.loads(decoded[20:20+len(body)])['meshes']==doc['meshes']
(prepared/'model.glb.gz').write_bytes(gzip.compress(decoded,mtime=0));write(prepared/'parts.json',meta)
base=copy.deepcopy(read(original/'PREPARATION_RECEIPT.json')['input'])
base.update(model=desc(prepared/'model.glb.gz',True),metadata=desc(prepared/'parts.json'))
write(prepared/'PREPARATION_RECEIPT.json',{'schema':'eva2-native-base-explicit-printed-annotation-v1',
    'original_model':desc(original/'model.glb.gz',True),'original_metadata':desc(original/'parts.json'),
    'unchanged_geometry_binary_chunk_sha256':sha(binarychunk),'unchanged_meshes_materials_matrices':True,
    'source_printed_keys':[f'eva2_vminion_lgx_bmo_{k}' for k in sorted(printed_indices)],
    'purchased_occurrences_explicit_false':78,'input':base})

