"""Remove only the four native 0.25mm hole-covering counterbore membranes."""
import json,hashlib,copy
from pathlib import Path
import native_module_preparer as n
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return {'file':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
proof=read(Q/'DRAGON_SOURCE_MEMBRANE_REVIEW.json')
selected=next(r for r in proof['rows'] if r['scope']=='native_counterbore_closure')
assert all(r['remaining_common_mm3']<1e-8 for r in selected['current_authored_fastener_common'])
inv=read(Q/'native-dragon/INVENTORY.json')['leaves'][6]
recipe=read(Q/'dragon-export-recipe.json')
recipe['native_source']=copy.deepcopy(recipe['native_source'])
recipe['native_source']['license']='GPL-3.0 STEP-page notice / CC-BY-NC-SA-4.0 tagged LICENSE; exact live CAD applicability unresolved'
before=Q/'native-dragon/6.brep'
assert pin(before)['sha256']==inv['brep_sha256']
after=Path(selected['prepared_brep']['file'])
assert pin(after)==selected['prepared_brep']
receipt={'operation':'source_bore_bridge_removal','source_sha256':recipe['native_source']['sha256'],
 'source_identity':[inv['source_path'],inv['source_label_path'],inv['definition_label']],
 'source_brep':pin(before),'prepared_brep':pin(after),
 'source_bore_closures':selected['caps'],'original_native_bounds_mm':selected['original_native_bounds_mm'],
 'prepared_native_bounds_mm':selected['prepared_native_bounds_mm'],
 'removed_volume_mm3':selected['source_volume_mm3']-selected['prepared_volume_mm3'],
 'current_authored_fastener_common':selected['current_authored_fastener_common'],
 'author_instruction_url':proof['author_post_print_instruction'],
 'native_preparation_review_sha256':pin(Q/'DRAGON_SOURCE_MEMBRANE_REVIEW.json')['sha256'],
 'scope':'Removed four complete native head-pocket hole closures, each exactly 0.25 mm thick between the authored shaft bore trim and authored head-pocket trim. Cutter radius is the native head-pocket radius, not a guessed clearance enlargement. Body outside these native closures and all outer mating geometry remain unchanged. Original author screws retained; no relocation.',
 'notice':'Four source hole-covering built-in bridge membranes have been removed from the Dragon face for assembled viewing; this prepared model differs from the untouched printable source.',
 'full_physical_fit_certified':False}
receiptfile=Q/'dragon-counterbore-closure-receipt-r5.json';n.json_write(receiptfile,receipt)
face=next(r for r in recipe['leaves'] if r['key']=='eva2_author_dragon_006')
face['native_preparation']={'receipt':pin(receiptfile),'source_brep':pin(before),'prepared_brep':pin(after)}
recipe['leaves']=[face];recipe['id']='eva2_author_dragon_prepared_face'
n.json_write(Q/'dragon-prepared-face-export-recipe-r5.json',recipe)
result=n.export(recipe,Q/'module-dragon-prepared-face-r5')
print(json.dumps({'parts':result['parts'],'model':result['model']}),flush=True)
