# Source notices and attribution

- EVA2 author: EVA-3D. Official STEP/live-CAD notice:
  https://2.eva-3d.page/step_files/ . Module reference pages:
  https://2.eva-3d.page/hotends/v6/ and
  https://2.eva-3d.page/hotends/dragon/ . LGX Lite reference:
  https://2.eva-3d.page/drives/lgx_lite/ . Live native assemblies are pinned by
  their actual Onshape microversions in PUBLIC_INPUTS.json. No patch version
  is inferred from these live exports.
- EVA2 tagged repository source at commit
  25837bdb2341230a4a393b60ccede8d904476718 has a CC-BY-NC-SA-4.0 LICENSE,
  while its STEP documentation and current official EVA2 STEP page contain
  a GPLv3 notice for STEP/live-CAD exports. Preserve the differing scopes;
  this archive does not decide a general legal resolution or assert a dual
  license. Original evidence bytes and hashes are included in licenses/.
- Retained V-Minion source: Rat Rig, public V-Minion v1.0 v7 assembly
  https://a360.co/3rPymJS . Its retained source scope is CC-BY-NC-SA-4.0;
  its native assembly revision and separate original public head buffers
  are pinned in PUBLIC_INPUTS.json. No blanket license is assigned to this
  mixed-source composition.
- Purchased components remain attributed through the actual native occurrence
  labels and source documents. Public export access alone is not an inferred
  grant of additional component rights.
- Changes: three author hole-covering membranes removed from the Universal
  face; Dragon additionally four native head-pocket closures; source PTFE
  cut to authored seats; Dragon uses the unchanged same-author V6 M3x25
  pair after measured axis checks. Outer mating geometry and source-carriage
  occurrence are retained. These prepared assembled-view parts differ from
  the untouched printable sources. Author post-print instruction:
  https://2.eva-3d.page/printing/#pokey-pokey-hole-technique .

Generator adapters preserve the acquired algorithms or explicitly identified
subsections. RETAINED_GENERATOR_PROVENANCE.json records original and packaged
code hashes; it is not a new CAD fit certification or a consolidated CAD license.
