"""Replay exact source occurrence identities and measured rigid transforms.

This modifies only a newly generated directory inside this source package.
--validate-only imports no native CAD or numerical library.
"""
import argparse, hashlib, json, math, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
NAME = 'dragon-v8-dragon-sherpa-mini'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def validate(recipe, inputs):
    families = {s['source_family_key'] for s in inputs['sources']}
    keys = [p['key'] for p in recipe['parts']]
    assert len(keys) == len(set(keys)) == 72
    for p in recipe['parts']:
        assert p['source_family'] in families
        assert p['source_id'] and p['source_index'] >= 0
        m = p['rigid_transform_mm']
        assert len(m) == 4 and all(len(r) == 4 for r in m)
        assert all(math.isfinite(v) for r in m for v in r)
        assert m[3] == [0, 0, 0, 1]
        for i in range(3):
            for j in range(3):
                assert abs(sum(m[k][i] * m[k][j] for k in range(3)) - (i == j)) < 1e-9
        assert p['file'] == 'native/' + p['key'] + '.brep'
    assert {p['key'] for p in recipe['parts'] if p.get('topology_repair')} == {'drive_203'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    recipe = json.loads((PACKAGE / 'recipe' / 'assembly.json').read_text(encoding='utf8'))
    inputs = json.loads((PACKAGE / 'INPUTS.json').read_text(encoding='utf8'))
    validate(recipe, inputs)
    if args.validate_only:
        print(json.dumps({'recipe_valid': True, 'parts': 72, 'source_families': 6, 'native_imports': 0}))
        return
    # Native imports are deliberately deferred until an explicit reproduction run.
    import cadquery as cq
    from OCP.gp import gp_Trsf
    from native_cq import load, bounds
    out = ROOT / NAME
    (out / 'native').mkdir(parents=True, exist_ok=True)
    for source in inputs['sources']:
        file = PACKAGE / source['bundle_step_path']
        assert sha(file) == source['native_STEP_sha256'], 'Wrong original author STEP'
        doc, leaves = load(file)
        selected = [p for p in recipe['parts'] if p['source_family'] == source['source_family_key']]
        for p in selected:
            leaf = leaves[p['source_index']]
            assert leaf['source_id'] == p['source_id'], 'Source occurrence identity changed'
            original = leaf['shape']
            temporary = out / 'source-identity.brep'
            original.exportBrep(str(temporary))
            assert sha(temporary) == p['source_brep_sha256'], 'Source topology digest differs; use locked runtime'
            # The original derivation also re-imported the exact serialized source cache.
            original = cq.Shape.importBrep(str(temporary))
            m = p['rigid_transform_mm']; tr = gp_Trsf()
            tr.SetValues(*[float(v) for row in m[:3] for v in row])
            placed = original.moved(cq.Location(tr))
            if p.get('topology_repair'):
                old = placed
                placed = old.fix()
                assert placed.isValid() and abs(placed.Volume() - old.Volume()) < 1e-6
            dest = out / p['file']; placed.exportBrep(str(dest))
            assert sha(dest) == p['native_brep_sha256'], 'Placed topology digest differs; do not waive'
            assert placed.isValid()
            actual_bounds = bounds(placed)
            assert max(abs(a-b) for a,b in zip(actual_bounds,p['bounds_mm'])) < 1e-8
            print(json.dumps({'key': p['key'], 'source_identity_verified': True, 'native_digest_verified': True}), flush=True)
        # One source assembly is loaded at a time; no parallel native workers.
        del selected, leaves, doc
    (out / 'source-identity.brep').unlink(missing_ok=True)
    (out / 'assembly.json').write_text(json.dumps(recipe, indent=2), encoding='utf8')
    print(json.dumps({'completed': True, 'parts': 72, 'native_workers': 1, 'output': NAME}))

if __name__ == '__main__': main()
