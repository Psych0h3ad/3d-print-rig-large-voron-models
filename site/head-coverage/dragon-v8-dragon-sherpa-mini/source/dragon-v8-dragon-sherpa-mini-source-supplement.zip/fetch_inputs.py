"""Fetch only the pinned public author inputs; no native CAD execution."""
import argparse, hashlib, json, urllib.request, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-urls', action='store_true', help='HEAD requests only; do not download CAD')
    args = parser.parse_args()
    data = json.loads((ROOT / 'INPUTS.json').read_text(encoding='utf8'))
    for source in data['sources']:
        if args.check_urls:
            req = urllib.request.Request(source['url'], method='HEAD', headers={'User-Agent': 'source-availability-check'})
            with urllib.request.urlopen(req, timeout=20) as r:
                assert r.status == 200
                print(json.dumps({'family': source['source_family_key'], 'status': r.status, 'url': source['url']}), flush=True)
            continue
        dest = ROOT / source['bundle_step_path']
        if dest.exists() and sha(dest) == source['native_STEP_sha256']:
            print(source['source_family_key'] + ': exact STEP already present', flush=True)
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        archive = dest.parent / ('upstream.zip' if source.get('archive_member') else 'upstream.step')
        req = urllib.request.Request(source['url'], headers={'User-Agent': 'pinned-source-reproducer'})
        with urllib.request.urlopen(req, timeout=60) as response, archive.open('wb') as out:
            for chunk in iter(lambda: response.read(1024 * 1024), b''): out.write(chunk)
        assert archive.stat().st_size == source['bytes'], source['source_family_key']
        assert sha(archive) == source['sha256'], source['source_family_key']
        if source.get('archive_member'):
            with zipfile.ZipFile(archive) as z:
                # Only this declared member is copied; archive paths are never extracted.
                with z.open(source['archive_member']) as member, dest.open('wb') as out:
                    for chunk in iter(lambda: member.read(1024 * 1024), b''): out.write(chunk)
        else:
            dest.write_bytes(archive.read_bytes())
        assert sha(dest) == source['native_STEP_sha256'], source['source_family_key']
        print(source['source_family_key'] + ': exact public input verified', flush=True)

if __name__ == '__main__': main()
