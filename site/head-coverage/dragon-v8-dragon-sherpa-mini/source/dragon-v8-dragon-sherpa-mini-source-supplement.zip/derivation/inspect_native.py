import json,sys
import cadquery as cq
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_SurfaceType
from OCP.TopoDS import TopoDS
from native_cq import ROOT,bounds
def xyz(p):return [p.X(),p.Y(),p.Z()]
def features(s):
    out=[]
    for i,f in enumerate(s.Faces()):
        a=BRepAdaptor_Surface(TopoDS.Face_s(f.wrapped),True);t=a.GetType()
        if t==GeomAbs_SurfaceType.GeomAbs_Cylinder:
            c=a.Cylinder();out.append({'face':i,'kind':'cylinder','radius':c.Radius(),'point':xyz(c.Location()),'axis':xyz(c.Axis().Direction()),'vspan':[a.FirstVParameter(),a.LastVParameter()],'area':f.Area()})
        elif t==GeomAbs_SurfaceType.GeomAbs_Plane:
            p=a.Plane();out.append({'face':i,'kind':'plane','point':xyz(p.Location()),'axis':xyz(p.Axis().Direction()),'center':f.Center().toTuple(),'area':f.Area()})
    return out
if __name__=='__main__':
    allout=[]
    for key in sys.argv[1:]:
        fam,ind=key.split(':');path=ROOT/'native-cache'/fam/(ind+'.brep')
        if not path.exists(): print(key,'not ready');continue
        s=cq.Shape.importBrep(str(path));fs=features(s)
        result={'key':key,'bounds':bounds(s),'valid':s.isValid(),'solids':len(s.Solids()),'features':fs};allout.append(result)
        print(key,'bounds',bounds(s),'valid',s.isValid(),'solids',len(s.Solids()))
        print(json.dumps([f for f in fs if (f['kind']=='cylinder' and 1.15<=f['radius']<=3.6) or (f['kind']=='plane' and f['area']>100)],indent=None))
    (ROOT/'inspected-features.json').write_text(json.dumps(allout,indent=2),'utf8')
