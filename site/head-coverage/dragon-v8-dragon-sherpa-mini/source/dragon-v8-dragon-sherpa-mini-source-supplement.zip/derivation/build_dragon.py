import json,hashlib
import numpy as np
import build_rapid as b
from native_cq import ROOT,bounds
from inspect_native import features
b.OUT=ROOT/'dragon-v8-dragon-sherpa-mini';b.OUT.mkdir(exist_ok=True)
b.NAMES.update({k:json.loads((ROOT/(k+'-names.json')).read_text()) for k in ['dragon-v8','dragon-native-v2','dragon-native-v3','v0r1']})
for i,k,r in [(24,'hotend_mount','printed_base'),(73,'extruder_plate','printed_base'),(0,'duct_left','printed_accent'),(9,'duct_right','printed_accent'),(11,'cowl','printed_base'),(84,'logo_diffuser','diffuser'),(88,'logo_carrier','printed_accent'),(89,'logo_led','led'),(106,'rear_brace','printed_base')]:
 b.add('dragon-v8',i,k,r,'printed' if r.startswith('printed') else 'led',t=[0,.032728799414,0] if i==24 else None)
hm=b.feat('dragon-v8',24,55);core=b.feat('archetype',204,28)
td=np.array([hm['point'][0]-core['point'][0],hm['point'][1]-core['point'][1],117.66432591814171-b.feat('archetype',204,602)['point'][2]])
for i in range(186,218):
 if i in [206,209]:continue
 n=b.NAMES['archetype'][i]['name'];r='printed_accent' if i in [204,205,207,208] else 'motor' if i==203 else 'brass' if 'insert' in n.lower() else 'metal'
 p=b.add('archetype',i,'drive_'+str(i),r,'drive',t=td)
 if not p['valid']:
  old=p['shape'];fixed=old.fix();assert fixed.isValid() and abs(old.Volume()-fixed.Volume())<1e-6
  fixed.exportBrep(str(b.OUT/p['file']));p.update({'shape':fixed,'valid':True,'native_brep_sha256':hashlib.sha256((b.OUT/p['file']).read_bytes()).hexdigest(),'topology_repair':{'method':'OCCT ShapeFix; native surfaces preserved','volume_delta_mm3':fixed.Volume()-old.Volume(),'minimum_distance_mm':old.distance(fixed)}})
b.PROOF.append({'interface':'Sherpa Mini A3 r9c / native Sherpa Mini plate','source_faces':[b.NAMES['archetype'][204]['source_id']+'#face[28,29,602]',b.NAMES['dragon-v8'][73]['source_id']+'#face[0,16,18]'],'engine_translation_mm':td.tolist(),'bore_pitch_mm':43.5,'maximum_radial_error_mm':.02006719967355,'seat_gap_mm':0})
R=np.diag([-1.,-1.,1.]);th=np.array([132.21711334539,-154.421806829689,50.75])
from OCP.BRepAdaptor import BRepAdaptor_Curve
src=np.array([[BRepAdaptor_Curve(b.get('dragon-native-v2',1).Edges()[i].wrapped).Circle().Location().X(),BRepAdaptor_Curve(b.get('dragon-native-v2',1).Edges()[i].wrapped).Circle().Location().Y()] for i in [109,143,177,211]])
dst=np.array([b.feat('dragon-v8',24,i)['point'][:2] for i in [83,86,95,96]])+[0,.032728799414]
# Match the four real thread circles to the four printed clearance bores, rigidly.
src=src[np.lexsort((src[:,1],src[:,0]))];dst=dst[np.lexsort((-dst[:,1]>-dst[:,1].mean(),-dst[:,0]>-dst[:,0].mean()))]
u,sv,vt=np.linalg.svd((src-src.mean(0)).T@(dst-dst.mean(0)));r2=vt.T@u.T
if np.linalg.det(r2)<0:vt[-1]*=-1;r2=vt.T@u.T
R[:2,:2]=r2;th[:2]=dst.mean(0)-r2@src.mean(0);threads=src@r2.T+th[:2];errors=np.linalg.norm(threads-dst,axis=1)
b.PROOF.append({'interface':'Dragon four native M2.5 threads / printed Dragon mount','source_thread_edge_ids':[b.NAMES['dragon-native-v2'][1]['source_id']+'#edge['+str(i)+']' for i in [109,143,177,211]],'target_clearance_face_ids':[b.NAMES['dragon-v8'][24]['source_id']+'#face['+str(i)+']' for i in [83,86,95,96]],'rigid_rotation':R.tolist(),'rigid_translation_mm':th.tolist(),'radial_residuals_mm':errors.tolist(),'minimum_remaining_radial_clearance_mm':float(.25-max(errors))})
for i in range(4):b.add('dragon-native-v2',i,'dragon_'+str(i),'hotend','hotend',R,th)
tf=np.array([132.21711334539,-154.429764074649,50.75])
for i,k in [(4,'fan_3010'),(14,'fan_4010_left'),(15,'fan_4010_right')]:b.add('dragon-native-v2',i,k,'fan','fan',np.diag([-1,-1,1]),tf+[0,1,1.3] if i==4 else tf)
b.PROOF.append({'interface':'Dragon native top seat / current Dragon mount','source_face':b.NAMES['dragon-native-v2'][1]['source_id']+'#face[366]','target_face':b.NAMES['dragon-v8'][24]['source_id']+'#face[29]','rotation':R.tolist(),'translation_mm':th.tolist(),'seat_gap_mm':0,'nozzle_z_mm':48.5905390309174,'note':'Exact authored Dragon assembly; HF/SF heatbreak version is not inferred from assembly name.'})
for j,f in enumerate([55,57]):
 h=b.feat('dragon-v8',24,f);p=np.array(h['point']);b.insert('drive_heatset_'+str(j),p.tolist(),[0,0,1])
 b.place_screw('archetype',6,'drive_mount_screw_'+str(j),[p[0],p[1],125.06432591814171],[0,0,-1])
for j,f in enumerate([84,86]):
 h=b.feat('dragon-v8',11,f);p=np.array(h['point']);b.insert('cowl_heatset_'+str(j),(p+[0,-2.5,0]).tolist(),[0,1,0])
 b.place_screw('archetype',6,'cowl_screw_'+str(j),[p[0],b.feat('dragon-v8',73,8)['point'][1],p[2]],[0,-1,0])
for j,xy in enumerate(threads):b.place_screw('xol-dragon',257,'hotend_screw_'+str(j),[xy[0],xy[1],98.26432591814279],[0,0,-1])
for j,f in enumerate([7,27]):
 h=b.feat('dragon-v8',106,f);b.place_screw('archetype',115,'brace_screw_'+str(j),[h['point'][0],-112.429764021511,h['point'][2]],[0,-1,0])
tc=np.array([147.675-0.0,-119.46249282092643-(-13.710505635122),103.79978375258419-277.949783752584])
# Align the native two-axis source pattern exactly; retain original carriage geometry.
cc=b.feat('v0r1',353,0);hh=b.feat('dragon-v8',24,125);tc=np.array(hh['point'])-np.array(cc['point']);tc[1]=b.feat('dragon-v8',73,24)['point'][1]-b.feat('v0r1',353,50)['point'][1]
b.add('v0r1',353,'v0r1_source_carriage','printed_base','carriage',t=tc)
for i,k in [(326,'mgn7h_block'),(374,'block_screw_0'),(383,'block_screw_1'),(384,'block_screw_2'),(385,'block_screw_3'),(398,'carriage_front_nut_0'),(398,'carriage_front_nut_1')]:b.add('v0r1',i,k,'metal','carriage',t=tc+[25,0,0] if k=='carriage_front_nut_1' else tc)
b.PROOF.append({'interface':'Dragon Burner / unchanged official Voron V0.2r1 carriage','source_id':b.NAMES['v0r1'][353]['source_id'],'source_faces':[0,1,13,50],'head_faces':[125,127],'rigid_translation_mm':tc.tolist(),'lateral_pitch_mm':25,'lateral_axis_residual_mm':0,'head_to_source_machine_translation_mm':(-tc).tolist(),'manufacturing_support_removed_source_index':354})
for j,f in enumerate([125,127]):
 h=b.feat('dragon-v8',24,f);b.place_screw('v0r1',381,'carriage_front_screw_'+str(j),[h['point'][0],-148.429764021512,h['point'][2]],[0,1,0])
# Rear central screw uses the existing native pocket and captured square nut.
h=b.feat('dragon-v8',73,44);p=np.array(h['point']);central=b.feat('v0r1',353,13);rear_seat=b.feat('v0r1',353,238)['center'][1]+tc[1]
b.place_screw('archetype',6,'carriage_rear_screw',[p[0],rear_seat,p[2]+.0132],[0,-1,0])
nut=b.get('archetype',183);a=next(x for x in features(nut) if x['kind']=='cylinder' and x['radius']<2);rn=b.rigid_axis(a['axis'],[0,1,0]);b.add('archetype',183,'carriage_square_nut','metal','fastener',rn,np.array([p[0],b.feat('dragon-v8',73,60)['point'][1]-.9,p[2]+.0132])-rn@np.array(nut.Center().toTuple()))
out={'id':'dragon_burner_v8_sherpa_mini_dragon_native','units':'mm','parts':[{k:v for k,v in p.items() if k!='shape'} for p in b.PARTS]}
(b.OUT/'assembly.json').write_text(json.dumps(out,indent=2),'utf8');(b.OUT/'mating-measurements.json').write_text(json.dumps(b.PROOF,indent=2),'utf8')
print(json.dumps({'parts':len(b.PARTS),'native_valid':all(p['valid'] for p in b.PARTS),'carriage_transform':tc.tolist()}))
