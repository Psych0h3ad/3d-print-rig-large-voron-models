import json,struct,gzip,hashlib,time,sys
import numpy as np
import cadquery as cq
from native_cq import ROOT
OUT=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'rapid-dragon-uhf-sherpa-mini');a=json.loads((OUT/'assembly.json').read_text('utf8'));parts=a['parts'];start=time.monotonic()
palette={'printed_base':([.12,.14,.17,1],0,.7),'printed_accent':([.78,.12,.16,1],0,.65),'diffuser':([.9,.94,1,.8],0,.75),'led':([.85,.9,.95,1],.2,.4),'metal':([.62,.65,.69,1],.8,.35),'motor':([.22,.23,.25,1],.7,.5),'fan':([.07,.08,.09,1],.05,.65),'brass':([.68,.45,.16,1],.8,.4),'hotend':([.62,.65,.68,1],.8,.4)}
j={'asset':{'version':'2.0','generator':'B129 source native CQ 2.6.1; mm X Y Z -> metre X Z -Y'},'scene':0,'scenes':[{'nodes':list(range(len(parts)))}],'nodes':[],'meshes':[],'materials':[],'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[]};binary=bytearray();materials={}
def data(arr,typ,ctype,target):
 while len(binary)%4:binary.append(0)
 off=len(binary);binary.extend(arr.tobytes());view=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':arr.nbytes,'target':target});ac={'bufferView':view,'componentType':ctype,'count':len(arr),'type':typ}
 if typ=='VEC3':ac|={'min':arr.min(0).tolist(),'max':arr.max(0).tolist()}
 else:ac|={'min':[int(arr.min())],'max':[int(arr.max())]}
 k=len(j['accessors']);j['accessors'].append(ac);return k
triangle_count=0;quantization_rejected=0
for k,p in enumerate(parts):
 s=cq.Shape.importBrep(str(OUT/p['file']));p['valid']=s.isValid();verts,tris=s.tessellate(.15,.25);v=np.array([x.toTuple() for x in verts]);tt=np.array(tris);tri=v[tt];n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);mag=np.linalg.norm(n,axis=1);keep=mag>1e-12;tri=tri[keep];n=n[keep]/mag[keep,None];triangle_count+=len(tri)
 # Verify triangle winding after GLB float32 quantization, rejecting subprecision slivers.
 pos=tri.reshape(-1,3)[:,[0,2,1]]*.001;pos[:,2]*=-1;pos=pos.astype('<f4').reshape(-1,3,3)
 expected=n[:,[0,2,1]].copy();expected[:,2]*=-1
 actual=np.cross(pos.astype(float)[:,1]-pos.astype(float)[:,0],pos.astype(float)[:,2]-pos.astype(float)[:,0]);amag=np.linalg.norm(actual,axis=1)
 good=(amag>1e-22)&(np.einsum('ij,ij->i',actual,expected)>0);quantization_rejected+=int((~good).sum());triangle_count-=int((~good).sum())
 norm=np.repeat(actual[good]/amag[good,None],3,axis=0);pos=pos[good].reshape(-1,3)
 pi=data(pos.astype('<f4'),'VEC3',5126,34962);ni=data(norm.astype('<f4'),'VEC3',5126,34962);ix=data(np.arange(len(pos),dtype='<u4'),'SCALAR',5125,34963)
 role=p['appearance_role']
 if role not in materials:
  color,metal,rough=palette[role];materials[role]=len(j['materials']);m={'name':role,'pbrMetallicRoughness':{'baseColorFactor':color,'metallicFactor':metal,'roughnessFactor':rough},'doubleSided':False}
  if color[3]<1:m['alphaMode']='BLEND'
  if role=='led':m['emissiveFactor']=[.5,.6,.8]
  j['materials'].append(m)
 j['meshes'].append({'name':p['key'],'primitives':[{'attributes':{'POSITION':pi,'NORMAL':ni},'indices':ix,'material':materials[role]}]});j['nodes'].append({'name':p['key'],'mesh':k,'extras':{'part_key':p['key'],'source_id':p['source_id'],'appearance_role':role}})
 color=palette[role][0];bb=p['bounds_mm'];p.update({'color':color,'motion':'xy','component':'toolhead' if p['group']!='carriage' else 'carriage','bounds_mm':[bb[:3],bb[3:]],'source_key':str(p['source_index']),'appearance_role':role.removeprefix('printed_')})
 while len(binary)%4:binary.append(0)
j['buffers'][0]['byteLength']=len(binary);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
b=struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary
(OUT/'model.glb').write_bytes(b);(OUT/'model.glb.gz').write_bytes(gzip.compress(b,compresslevel=9,mtime=0))
meta={'id':a['id'],'parts':parts,'glb':'model.glb','valid':all(p['valid'] for p in parts),'geometry_revision':'b129-'+OUT.name+'-native-1','complete_detail':True,'coordinate_frame':'renderer_metre_XZ_minusY_from_original_native_CAD_mm','absolute_mesh_deflection_mm':.15,'mesh_angular_tolerance_rad':.25,'source_version':'Chirpy Dragon Burner v8 / native Dragon Burner v2 hardware / Sherpa Mini A3 r9c / official Voron V0.2r1 carriage','native_review':'native-proof.json','companion_manifest':'companion-manifest.json','notices':['Native hardware reused without rescaling or synthetic replacement. Source carriage manufacturing support is excluded. Review native-proof.json for the exact inspection scope.']}
(OUT/'parts.json').write_text(json.dumps(meta,indent=2),'utf8')
(OUT/'export-receipt.json').write_text(json.dumps({'parts':len(parts),'triangles':triangle_count,'float32_subprecision_slivers_rejected':quantization_rejected,'all_exported_native_valid':meta['valid'],'bytes':len(b),'seconds':time.monotonic()-start,'sha256':hashlib.sha256(b).hexdigest(),'gz_sha256':hashlib.sha256((OUT/'model.glb.gz').read_bytes()).hexdigest()},indent=2),'utf8')
print(json.dumps({'parts':len(parts),'triangles':triangle_count,'all_exported_native_valid':meta['valid'],'bytes':len(b),'seconds':time.monotonic()-start}))
