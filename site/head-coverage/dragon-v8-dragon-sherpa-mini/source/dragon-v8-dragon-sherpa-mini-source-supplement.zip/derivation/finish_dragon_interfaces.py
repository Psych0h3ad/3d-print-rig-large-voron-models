import json,hashlib,numpy as np,cadquery as cq
import build_rapid as b
from native_cq import ROOT,bounds
b.OUT=ROOT/'dragon-v8-dragon-sherpa-mini';a=json.loads((b.OUT/'assembly.json').read_text('utf8'));parts=a['parts'];proof=json.loads((b.OUT/'mating-measurements.json').read_text('utf8'))
b.NAMES['v0r1']=json.loads((ROOT/'v0r1-names.json').read_text('utf8'))
rear=next(p for p in parts if p['key']=='carriage_rear_screw');car=next(p for p in parts if p['key']=='v0r1_source_carriage');tc=np.array(car['rigid_transform_mm'])[:3,3]
pr=next(p for p in proof if p.get('interface')=='carriage_rear_screw');seat=b.feat('v0r1',353,238)['center'][1]+tc[1];delta=seat-pr['target_seat_mm'][1]
s=cq.Shape.importBrep(str(b.OUT/rear['file'])).translate((0,delta,0));s.exportBrep(str(b.OUT/rear['file']));rear['native_brep_sha256']=hashlib.sha256((b.OUT/rear['file']).read_bytes()).hexdigest();rear['bounds_mm']=bounds(s);rear['rigid_transform_mm'][1][3]+=delta;pr['target_seat_mm'][1]=seat;pr['target_seat_face_id']=b.NAMES['v0r1'][353]['source_id']+'#face[238]'
n=b.add('v0r1',398,'carriage_front_nut_1','metal','carriage',t=tc+[25,0,0]);n={k:v for k,v in n.items() if k!='shape'};parts[parts.index(next(p for p in parts if p['key']==n['key']))]=n
proof.extend([
 {'interface':'Dragon mount / cowl front seating planes','source_face_ids':[json.loads((ROOT/'dragon-v8-names.json').read_text('utf8'))[24]['source_id']+'#face[11]',json.loads((ROOT/'dragon-v8-names.json').read_text('utf8'))[11]['source_id']+'#face[79]'],'hotend_mount_translation_correction_mm':[0,.032728799414,0],'seat_gap_mm':0},
 {'interface':'3010 native fan / source friction aperture','source_face_id':json.loads((ROOT/'dragon-native-v2-names.json').read_text('utf8'))[4]['source_id']+'#face[4]','target_face_id':json.loads((ROOT/'dragon-v8-names.json').read_text('utf8'))[11]['source_id']+'#face[210]','native_axis_radius_mm':14,'axis_center_mm':[147.66694674086,-153.429764074649,83.3499997466803],'axis_residual_mm':0,'retention_requirement':'Author specifies friction fit; frame lip contacts classified separately from fan rotor clearance.'},
 {'interface':'rear square nut / exact native plate pocket','pocket_face_ids':[47,50,52,60],'source_pocket_id':json.loads((ROOT/'dragon-v8-names.json').read_text('utf8'))[73]['source_id'],'native_nut_size_mm':[5.5,1.8,5.5],'nut_and_screw_z_offset_from_nominal_bore_mm':.0132,'minimum_carriage_radial_screw_clearance_mm':.17,'nut_seat_y_mm':b.feat('dragon-v8',73,60)['point'][1]},
 {'interface':'two carriage captive front nuts','source_id':b.NAMES['v0r1'][398]['source_id'],'native_geometry_unchanged':True,'right_instance_translation_relative_to_left_mm':[25,0,0],'note':'Reuse correctly oriented native left nut in symmetric right pocket; source right occurrence has an angular pose discrepancy.'}
])
(b.OUT/'assembly.json').write_text(json.dumps(a,indent=2),'utf8');(b.OUT/'mating-measurements.json').write_text(json.dumps(proof,indent=2),'utf8');print(json.dumps({'parts':len(parts),'rear_seat_correction_mm':delta,'source_carriage_unchanged':True}))
