"""Assemble existing source bodies by their measured native mating features."""
import json,math,hashlib
import numpy as np
import cadquery as cq
from native_cq import ROOT,bounds
from inspect_native import features
from OCP.gp import gp_Trsf,gp_Mat,gp_Vec,gp_XYZ

OUT=ROOT/'rapid-dragon-uhf-sherpa-mini';OUT.mkdir(exist_ok=True)
PARTS=[];PROOF=[]
NAMES={f:json.loads((ROOT/(f+'-names.json')).read_text('utf8')) for f in ['rapid','archetype','dragoncombo','xol-dragon','v0']}
def get(f,i):return cq.Shape.importBrep(str(ROOT/'native-cache'/f/(str(i)+'.brep')))
def transform(s,R,t):
    tr=gp_Trsf();tr.SetValues(*[float(v) for row in np.c_[R,t] for v in row]);return s.moved(cq.Location(tr))
def add(f,i,key,role,group,R=None,t=None):
    R=np.eye(3) if R is None else np.array(R);t=np.zeros(3) if t is None else np.array(t)
    src=ROOT/'native-cache'/f/(str(i)+'.brep');s=transform(get(f,i),R,t);n=NAMES[f][i]
    dest=OUT/'native';dest.mkdir(exist_ok=True);file=dest/(key+'.brep');s.exportBrep(str(file))
    p={'key':key,'name':n['name'],'source_id':n['source_id'],'source_family':f,'source_index':i,'source_brep_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
       'rigid_transform_mm':[list(row) for row in np.vstack([np.c_[R,t],[0,0,0,1]])],
       'file':'native/'+file.name,'native_brep_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bounds_mm':bounds(s),'volume_mm3':s.Volume(),'valid':s.isValid(),'solids':len(s.Solids()),
       'appearance_role':role,'group':group,'shape':s}
    PARTS.append(p);return p
def feat(f,i,k):return next(x for x in features(get(f,i)) if x['face']==k)
def xyz(a):return np.array(a,dtype=float)
def rigid_axis(a,b):
    a=xyz(a)/np.linalg.norm(a);b=xyz(b)/np.linalg.norm(b);v=np.cross(a,b);c=np.dot(a,b)
    if c>1-1e-12:return np.eye(3)
    if c<-1+1e-12:
        u=np.cross(a,[1,0,0] if abs(a[0])<.9 else [0,1,0]);u/=np.linalg.norm(u);return 2*np.outer(u,u)-np.eye(3)
    K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]);return np.eye(3)+K+K@K/(1+c)
def place_screw(f,i,key,seat,direction,group='fastener'):
    fs=features(get(f,i));cs=[x for x in fs if x['kind']=='cylinder'];maxr=max(x['radius'] for x in cs)
    sh=max((x for x in cs if abs(x['radius']-(1.25 if 'hotend' in key else 1.5))<.02),key=lambda x:x['area'])
    hp=max((x for x in cs if x['radius']>maxr-.1),key=lambda x:x['area']);hc=xyz(hp['point'])+xyz(hp['axis'])*np.mean(hp['vspan'])
    ends=[xyz(sh['point'])+xyz(sh['axis'])*x for x in sh['vspan']];head=min(ends,key=lambda p:np.linalg.norm(p-hc));tip=max(ends,key=lambda p:np.linalg.norm(p-hc));d=(tip-head)/np.linalg.norm(tip-head)
    cylindrical_head=head.copy()
    planes=[x for x in fs if x['kind']=='plane' and abs(np.dot(xyz(x['axis']),d))>.999999 and abs(np.dot(xyz(x['point'])-head,d))<1 and x['area']>1]
    assert planes,'No native screw head underside plane'
    seatface=min(planes,key=lambda x:abs(np.dot(xyz(x['point'])-head,d)))
    head=head+d*np.dot(xyz(seatface['point'])-head,d)
    R=rigid_axis(d,direction);t=xyz(seat)-R@head;p=add(f,i,key,'metal',group,R,t)
    PROOF.append({'interface':key,'source_shank_face_id':NAMES[f][i]['source_id']+'#face['+str(sh['face'])+']','source_seat_face_id':NAMES[f][i]['source_id']+'#face['+str(seatface['face'])+']','source_head_shank_boundary_mm':head.tolist(),'target_seat_mm':list(seat),'target_direction':list(direction),'native_shank_cylindrical_length_mm':float(np.linalg.norm(tip-cylindrical_head)),'native_underhead_to_tip_mm':float(np.linalg.norm(tip-head))})
    return p
def insert(key,target,axis):
    f,i='dragoncombo',42;s=get(f,i);fs=features(s);c=max((x for x in fs if x['kind']=='cylinder'),key=lambda x:x['radius']);a=xyz(c['axis']);point=xyz(c['point'])
    dots=[np.dot(x.toTuple(),a) for x in s.Vertices()];center=point+a*((min(dots)+max(dots))/2-np.dot(point,a));R=rigid_axis(a,axis);t=xyz(target)-R@center
    add(f,i,key,'brass','heatset',R,t)
    PROOF.append({'interface':key,'source_axis_face_id':NAMES[f][i]['source_id']+'#face['+str(c['face'])+']','source_axial_length_mm':max(dots)-min(dots),'target_center_mm':list(target),'target_axis':list(axis),'classification':'intended heat-set press engagement'})

if __name__=='__main__':
    # Cowl, two separate ducts, exact UHF hotend mount, and logo LED companions.
    for i,k,r in [(2,'hotend_mount','printed_base'),(33,'duct_left','printed_accent'),(42,'duct_right','printed_accent'),(44,'cowl','printed_base'),(58,'logo_diffuser','diffuser'),(61,'logo_carrier','printed_accent'),(62,'logo_led','led'),(99,'rear_brace','printed_base')]:add('rapid',i,k,r,'printed' if r.startswith('printed') else 'led')
    hm=feat('rapid',2,155);pl=feat('rapid',23,9);t_plate=xyz(hm['point'])-xyz(pl['point']);t_plate[2]=feat('rapid',2,32)['point'][2]-feat('rapid',23,4)['point'][2]
    add('rapid',23,'extruder_plate','printed_base','printed',t=t_plate)
    PROOF.append({'interface':'extruder plate / hotend mount','source_features':[NAMES['rapid'][23]['source_id']+'#face[4]',NAMES['rapid'][23]['source_id']+'#face[9]',NAMES['rapid'][2]['source_id']+'#face[32]',NAMES['rapid'][2]['source_id']+'#face[155]'],'correction_from_authored_layout_mm':t_plate.tolist(),'matched_bore_pitch_mm':43.5,'seat_gap_mm':0})
    # Entire Sherpa Mini A3 r9c engine, with mutually exclusive housing/idler variants removed.
    core=feat('archetype',204,28);p0=xyz(core['point']);target=xyz(hm['point']);target[2]=feat('rapid',23,0)['point'][2]+t_plate[2]
    corebottom=bounds(get('archetype',204))[2]+1e-7;t_drive=target-p0;t_drive[2]=target[2]-corebottom
    for i in range(186,218):
        if i in [206,209]:continue
        n=NAMES['archetype'][i]['name'];role='printed_accent' if i in [204,205,207,208] else ('motor' if i==203 else ('brass' if 'insert' in n.lower() else 'metal'))
        add('archetype',i,'drive_'+str(i),role,'drive',t=t_drive)
    PROOF.append({'interface':'Sherpa Mini / extruder plate','source_features':[NAMES['archetype'][204]['source_id']+'#face[28]',NAMES['archetype'][204]['source_id']+'#face[29]',NAMES['rapid'][23]['source_id']+'#face[9]',NAMES['rapid'][23]['source_id']+'#face[13]'],'bore_pitch_mm':43.5,'translation_mm':t_drive.tolist(),'seat_z_mm':target[2],'seat_gap_mm':0})
    # Full 62.5 mm Dragon UHF from Xol's authored guide; the shorter no-spacer Archetype model is excluded.
    fs=features(get('xol-dragon',263));bores=[]
    for j in [257,258,261,262]:
        bf=features(get('xol-dragon',j));axis=max((x for x in bf if x['kind']=='cylinder' and abs(x['radius']-1.25)<.001),key=lambda x:x['area'])
        matching=[x for x in fs if x['kind']=='cylinder' and .9<x['radius']<1.4 and abs(x['axis'][2])>.999 and np.linalg.norm(xyz(x['point'][:2])-xyz(axis['point'][:2]))<.01]
        assert matching
        bores.append(max(matching,key=lambda x:x['area']))
    assert len(bores)==4
    src=np.array([b['point'][:2] for b in bores]);dst=np.array([feat('rapid',2,i)['point'][:2] for i in [198,199,200,201]])
    # Author dimensions have tiny manufacturing-layout residuals; fit a rigid planar transform, never scale.
    src=src[np.lexsort((src[:,1]>src[:,1].mean(),src[:,0]>src[:,0].mean()))];dst=dst[np.lexsort((dst[:,1]>dst[:,1].mean(),dst[:,0]>dst[:,0].mean()))]
    u,sv,vt=np.linalg.svd((src-src.mean(0)).T@(dst-dst.mean(0)));R2=vt.T@u.T
    if np.linalg.det(R2)<0:vt[-1]*=-1;R2=vt.T@u.T
    R=np.eye(3);R[:2,:2]=R2;t=np.zeros(3);t[:2]=dst.mean(0)-R2@src.mean(0);t[2]=feat('rapid',2,239)['point'][2]-feat('xol-dragon',263,420)['point'][2]
    hot=add('xol-dragon',263,'dragon_uhf','hotend','hotend',R,t);errors=np.linalg.norm(src@R2.T+t[:2]-dst,axis=1)
    PROOF.append({'interface':'Dragon UHF / Rapid Burner UHF mount','source_thread_face_ids':[NAMES['xol-dragon'][263]['source_id']+'#face['+str(x['face'])+']' for x in bores],'target_clearance_face_ids':[NAMES['rapid'][2]['source_id']+'#face['+str(i)+']' for i in [198,199,200,201]],'radial_axis_residuals_mm':errors.tolist(),'minimum_remaining_radial_m2_5_clearance_mm':float(.25-max(errors)),'seat_gap_mm':0,'full_native_hotend_height_mm':62.5,'nozzle_lowest_mm':hot['bounds_mm'][2]})
    for j,xy in enumerate(src@R2.T+t[:2]):place_screw('xol-dragon',257,'hotend_screw_'+str(j),[xy[0],xy[1],114.7143259181408],[0,0,-1])
    # Exact Lineux fans: source dimensions preserved, matched to native aperture and duct seats.
    aperture=feat('rapid',44,147);axfan=feat('dragoncombo',63,1);t_fan=xyz(aperture['point'])-xyz(axfan['center']);t_fan[1]+=1
    add('dragoncombo',63,'fan_3010','fan','fan',t=t_fan)
    shift=np.array([147.71711334539-127.00001856,-154.429764021511-78.349719229205,62.75-30.0556744])
    add('dragoncombo',40,'fan_4010_right','fan','fan',t=shift);add('dragoncombo',41,'fan_4010_left','fan','fan',t=shift)
    PROOF.append({'interface':'3010 fan / cowl aperture','source_face_id':NAMES['dragoncombo'][63]['source_id']+'#face[1]','target_aperture_face_id':NAMES['rapid'][44]['source_id']+'#face[147]','translation_mm':t_fan.tolist(),'front_seat_y_mm':-153.429764021512,'axial_aperture_offset_mm':0,'fastener_requirement':'source author screwless fan retention'})
    PROOF.append({'interface':'two 4010 blowers / native cowl and ducts','source_ids':[NAMES['dragoncombo'][i]['source_id'] for i in [40,41]],'native_seat_extent_mm':{'y':[-154.429764021511,-114.429764021511],'z':[62.75,102.75]},'translation_mm':shift.tolist(),'fastener_requirement':'source author screwless fan retention'})
    for j,face in enumerate([152,155]):
        h=feat('rapid',2,face);p=xyz(h['point']);insert('drive_heatset_'+str(j),(p+np.array([0,0,-2.4])).tolist(),[0,0,1])
        # M3x20 as listed by the author; native engagement/body audit determines acceptance.
        seat=[p[0],p[1],32.1575880786226+t_drive[2]];place_screw('archetype',6,'drive_mount_screw_'+str(j),seat,[0,0,-1])
    for j,face in enumerate([96,97]):
        h=feat('rapid',2,face);p=xyz(h['point']);insert('cowl_heatset_'+str(j),(p+np.array([0,2.4,0])).tolist(),[0,1,0])
        place_screw('xol-dragon',259,'cowl_screw_'+str(j),[p[0],-143.429764021511,p[2]],[0,1,0])
    # Rear brace screws use existing author-provided M3x6 bodies, not regenerated hardware.
    bracefs=features(get('rapid',99));h=[a for a in bracefs if a['kind']=='cylinder' and 1.4<a['radius']<1.8]
    for j,x in enumerate(h[:2]):place_screw('archetype',115,'brace_screw_'+str(j),[x['point'][0],-112.429764021511,x['point'][2]],[0,-1,0])
    # Original V0.2 carriage is copied without alteration; head is registered by its three native axes.
    shift_car=np.array([147.678836487264-0.0018364872686,-119.430685942505-(-13.710505635122),103.649783752584-277.949783752584])
    add('v0',345,'v0_source_carriage','printed_base','carriage',t=shift_car)
    PROOF.append({'interface':'Rapid Burner / unchanged Voron V0.2 X carriage','source_carriage_id':NAMES['v0'][345]['source_id'],'source_carriage_brep_sha256':hashlib.sha256((ROOT/'native-cache/v0/345.brep').read_bytes()).hexdigest(),'target_mount_face_ids':[NAMES['rapid'][2]['source_id']+'#face['+str(i)+']' for i in [161,206,129]],'carriage_bore_face_ids':[NAMES['v0'][345]['source_id']+'#face['+str(i)+']' for i in [0,1,13]],'source_to_head_translation_mm':shift_car.tolist(),'lateral_pitch_mm':25.0,'lateral_axis_residual_mm':0,'central_axis_residual_mm':147.718021838248-147.678836487264,'front_seat_gap_mm':0,'head_to_source_machine_translation_mm':(-shift_car).tolist()})
    for j,face in enumerate([161,206]):
        h=feat('rapid',2,face);place_screw('archetype',63,'carriage_front_screw_'+str(j),[h['point'][0],-126.430685942505,h['point'][2]],[0,1,0])
    h=feat('rapid',2,129);place_screw('archetype',6,'carriage_rear_screw',[h['point'][0],12.289494364878+shift_car[1],h['point'][2]],[0,-1,0])
    # Captured M3 square nut at rear central axis, sourced exact 5.5 x 1.8 mm native body.
    nut=get('archetype',183);nf=features(nut);axis=next(a for a in nf if a['kind']=='cylinder' and a['radius']<2);c=nut.Center().toTuple();Rnut=rigid_axis(axis['axis'],[0,1,0]);targetnut=[h['point'][0],-125.12,h['point'][2]];add('archetype',183,'carriage_square_nut','metal','fastener',Rnut,xyz(targetnut)-Rnut@xyz(c))
    # Native absolute geometry and source receipts remain alongside every export.
    manifest={'id':'rapid_dragon_uhf_sherpa_mini_native','units':'mm','source_scope':'Rigid source geometry, no approximated hardware','parts':[{k:v for k,v in p.items() if k!='shape'} for p in PARTS]}
    (OUT/'assembly.json').write_text(json.dumps(manifest,indent=2),'utf8');(OUT/'mating-measurements.json').write_text(json.dumps(PROOF,indent=2),'utf8')
    print(json.dumps({'parts':len(PARTS),'all_native_valid':all(p['valid'] for p in PARTS),'printed_parts':sum(p['appearance_role'].startswith('printed') for p in PARTS),'fans':3,'hotend_height_mm':62.5,'max_hotend_axis_error_mm':max(errors),'nozzle_z_mm':hot['bounds_mm'][2]},indent=2))
