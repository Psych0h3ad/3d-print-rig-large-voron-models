"""Read author XCAF occurrences without changing their rigid placements."""
import json, hashlib
from pathlib import Path
import cadquery as cq
from OCP.TDF import TDF_Label, TDF_LabelSequence, TDF_Tool
from OCP.TCollection import TCollection_ExtendedString, TCollection_AsciiString
from OCP.TDataStd import TDataStd_Name
from OCP.TDocStd import TDocStd_Document
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ShapeTool
from OCP.TopLoc import TopLoc_Location
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box

ROOT=Path(__file__).resolve().parent
def name(l):
    a=TDataStd_Name()
    return a.Get().ToExtString() if l.FindAttribute(TDataStd_Name.GetID_s(),a) else '<anonymous>'
def entry(l):
    a=TCollection_AsciiString();TDF_Tool.Entry_s(l,a);return a.ToCString()
def bounds(s):
    b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False)
    return list(b.Get())
def load(p):
    d=TDocStd_Document(TCollection_ExtendedString('BinXCAF'));r=STEPCAFControl_Reader();r.SetNameMode(True);r.SetColorMode(True)
    assert int(r.ReadFile(str(p)))==1 and r.Transfer(d)
    t=XCAFDoc_DocumentTool.ShapeTool_s(d.Main());q=TDF_LabelSequence();t.GetFreeShapes(q);out=[]
    def walk(l,loc,anc):
        a=TDF_Label();ref=XCAFDoc_ShapeTool.GetReferredShape_s(l,a);a=a if ref else l
        loc=loc.Multiplied(XCAFDoc_ShapeTool.GetLocation_s(l)) if ref else loc
        n=name(l);n=name(a) if n=='<anonymous>' else n;path=anc+[n];seq=TDF_LabelSequence()
        if XCAFDoc_ShapeTool.GetComponents_s(a,seq,False):
            for i in range(1,seq.Length()+1):walk(seq.Value(i),loc,path)
        else:
            s=XCAFDoc_ShapeTool.GetShape_s(a)
            if not s.IsNull():out.append({'source_id':entry(l)+'@'+'/'.join(path),'definition_label':entry(a),'name':name(a),'path':path,'shape':cq.Shape.cast(s.Moved(loc))})
    for i in range(1,q.Length()+1):walk(q.Value(i),TopLoc_Location(),[])
    return d,out
def info(l):
    s=l['shape']
    try: bb=bounds(s)
    except Exception: bb=None
    return {k:v for k,v in l.items() if k!='shape'}|{'bounds_mm':bb,'volume_mm3':s.Volume(),'valid':s.isValid(),'solids':len(s.Solids())}
if __name__=='__main__':
    import sys,time
    p=Path(sys.argv[1]);key=sys.argv[2];start=time.monotonic();d,l=load(p)
    dest=ROOT/'native-cache'/key;dest.mkdir(parents=True,exist_ok=True)
    print(json.dumps({'loaded':key,'leaves':len(l)}),flush=True)
    (ROOT/(key+'-names.json')).write_text(json.dumps([{k:v for k,v in a.items() if k!='shape'} for a in l],indent=2),'utf8')
    result=[]
    for i,a in enumerate(l):
        a['shape'].exportBrep(str(dest/(str(i)+'.brep')));result.append(info(a)|{'cache':str(dest/(str(i)+'.brep')),'index':i})
    (ROOT/(key+'-inventory.json')).write_text(json.dumps({'source_file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'leaves':result},indent=2),'utf8')
    from collections import Counter
    print(json.dumps({'key':key,'leaves':len(l),'seconds':time.monotonic()-start,'groups':Counter('/'.join(a['path'][:3]) for a in l)},indent=2))
