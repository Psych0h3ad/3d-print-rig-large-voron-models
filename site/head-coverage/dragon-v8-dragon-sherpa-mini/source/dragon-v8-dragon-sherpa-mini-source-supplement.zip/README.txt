Reproduce the selected Dragon Burner v8 / native Dragon / Sherpa Mini A3 r9c export

1. Use the Python version and package versions in RUNTIME.json. Install requirements.txt in an isolated environment.
2. Run: python fetch_inputs.py
   This downloads only the six commit-pinned public inputs, verifies the exact archive/STEP hashes, and extracts only each declared STEP member. --check-urls performs only HEAD requests.
3. Run: python generator/replay_native.py --validate-only
   This is a non-CAD recipe check and imports no native libraries.
4. Run: python generator/replay_native.py
   This loads one original author STEP at a time, verifies each source occurrence identity and serialized topology hash, applies the stored rigid transform and only the recorded motor ShapeFix, and verifies every placed native hash. All generated BREP caches stay under generator/dragon-v8-dragon-sherpa-mini/native/.
5. Run: python generator/export_rapid.py dragon-v8-dragon-sherpa-mini
   This is the exact retained exporter: 0.15 mm / 0.25 rad tessellation, X/Z/-Y metre mapping, finite normals and float32 sliver filtering, original material palette, deterministic gzip settings.
6. Compare parts.json and model.glb.gz against EXPECTED_EXPORTS.json. recipe/expected-parts.json is the exact frozen public metadata. A different native/runtime serialization or exporter result is a failure to reproduce that frozen export; do not waive its hash.

Original feature-measurement derivation scripts are preserved in derivation/. They document how the measured transforms and source selections were obtained. Their historical cache setup includes unused earlier candidate inputs; the supported minimal replay above needs only the six used input families and the frozen explicit assembly recipe.

recipe/companion-manifest.json records complete source companions and excluded alternatives. Publish an unchanged copy beside the existing public parts.json, because that metadata names companion-manifest.json but the five-file publication list omitted it. recipe/installation.json records the existing source carriage/host transform, exact installation attachment keys, LED registration and restricted display region. The public viewer supplies the machine model and adapters; the existing ../installed/INSTALLATION_PROOF.json remains the authority for its scope and limits.

The source CAD is accessible through INPUTS.json URLs; this supplement does not mirror the large original archives. For an offline source distribution, include the six inputs/<family>/source.step files obtained by the hash-verifying fetcher. Raw native BREP caches are unnecessary to distribute because the supplied original CAD and generator recreate them.

See NOTICES.txt and LICENSE_INDEX.json. Exact component license exceptions beyond the included repository notices are not established by the current provenance. No claim that all components of this mixed-source head are GPL is made.
